SoftSin Composer Suite — Version 1.0.0
-------------------------------------

This folder contains the official SoftSin Composer Suite release and its
cryptographic signature. Both files must stay together.

Included files:
- softsin_composer_suite_V1_0_0.zip        (the Composer Suite release)
- softsin_composer_suite_V1_0_0.zip.asc    (the authenticity signature)
- README.txt                               (this file)


WHAT THE .ASC FILE IS
---------------------
The .asc file is a digital signature created with the official SoftSin
Studios signing key. It proves that the release zip file:

1. Was created by SoftSin Studios.
2. Has not been modified or tampered with.


HOW TO VERIFY THIS RELEASE (Windows)
------------------------------------
1. Open the folder containing these files.

2. In the folder’s address bar (top of the window), click once and type:
      powershell
   Then press Enter.

   This opens PowerShell directly in the correct folder.

3. To download the SoftSin Studios public key automatically, run this in PowerShell:

      Invoke-WebRequest "https://raw.githubusercontent.com/SoftSinStudios/softsin-release-store/main/PUBLIC-KEY.asc" -OutFile "PUBLIC-KEY.asc"

4. Verify the release:

      gpg --verify softsin_composer_suite_V1_0_0.zip.asc softsin_composer_suite_V1_0_0.zip

5. If the file is authentic, PowerShell will show:
      Good signature from "SoftSin Studios Release (Official build signing key)"

If you do NOT see "Good signature", do NOT use the file.


OFFICIAL SOFTSIN STUDIOS SIGNING KEY FINGERPRINT
------------------------------------------------
4BF1 2AEA 7E09 E837 11F7 0721 4F53 240E 4DA4 BD75


SUPPORT & INFO
--------------
Website: https://www.softsinstudios.com
Facebook: https://www.facebook.com/softsinstudios

SoftSin Studios — Tools for the New Creative Age
