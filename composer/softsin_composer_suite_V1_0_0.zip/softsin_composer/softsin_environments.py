# softsin_environments.py
# SoftSin Environments — dropdowns mirror groups in softsin_environments.json
# Reads: softsin_data/softsin_environments.json
#
# JSON schema (recommended):
# {
#   "environments": [
#     {
#       "name": "alien_planet",
#       "prompts": [
#         {"name":"alien_shallows","text":"ankle_deep in shimmering alien water, ..."},
#         {"name":"crystal_basin","text":"vast crystalline basin with liquid light ..."}
#       ]
#     }
#   ]
# }
#
# Back-compat: if a prompt is a plain string, we auto-name it "p1", "p2", etc.

import os, json, math

NONE = "(none)"

# ---------- helpers ----------
def _is_set(x):
    return x not in (None, "", NONE)

def _wrap(token: str, w: float, fmt: str) -> str:
    s = (token or "").strip()
    if not _is_set(s):
        return ""
    try:
        w = float(w)
        if not math.isfinite(w):
            w = 1.0
    except Exception:
        w = 1.0
    if fmt == "plain" or abs(w - 1.0) < 1e-6:
        return s
    if fmt == "weighted_parentheses":
        return f"({s}:{w:.2f})"
    if fmt == "brackets":
        return f"[{s}]"
    return s

def _sanitize_weight(w: float, default=1.0, wmin=0.0, wmax=2.0):
    try:
        v = float(w)
        if not math.isfinite(v):
            return default
    except Exception:
        return default
    return max(wmin, min(wmax, v))

def _data_dir():
    here = os.path.dirname(os.path.abspath(__file__))
    for p in (
        os.path.join(here, "softsin_data"),
        os.path.join(os.path.dirname(here), "softsin_data"),
    ):
        if os.path.isdir(p):
            return p
    p = os.path.join(here, "softsin_data")
    os.makedirs(p, exist_ok=True)
    return p

def _load_json(filename: str):
    path = os.path.join(_data_dir(), filename)
    try:
        with open(path, "r", encoding="utf-8-sig") as f:
            return json.load(f)
    except Exception as e:
        print(f"[SoftSinEnvironments] Warning: could not load {filename}: {e}")
        return {"environments": []}

def _coerce_envs(doc):
    """Return a list of env dicts with normalized 'name' and list of (prompt_name, text)."""
    out = []
    for env in (doc.get("environments") or []):
        if not isinstance(env, dict):
            continue
        name = env.get("name")
        if not _is_set(name):
            continue
        prompts = env.get("prompts") or []
        norm = []
        idx = 1
        for p in prompts:
            if isinstance(p, dict):
                nm = p.get("name") or f"p{idx}"
                tx = p.get("text") or ""
            else:
                nm = f"p{idx}"
                tx = str(p or "")
            nm = nm.strip()
            tx = tx.strip()
            if _is_set(tx):
                # Avoid collisions in names
                base = nm or f"p{idx}"
                while any(base == n for n, _ in norm):
                    idx += 1
                    base = f"p{idx}"
                norm.append((base, tx))
            idx += 1
        out.append({"name": name, "options": norm})
    return out

# ---------- load & normalize at import ----------
_DOC = _load_json("softsin_environments.json")
_ENVS = [e for e in _coerce_envs(_DOC) if e.get("name") and e.get("options")]

# Build groups directly from JSON order (no padding; no dummy group_10)
_GROUPS = []
for env in _ENVS:
    display = env["name"]
    names = [n for n, _ in env["options"]]
    opts = tuple([NONE] + names) if names else (NONE,)
    mapping = {n: t for n, t in env["options"]}
    _GROUPS.append({"key": display, "opts": opts, "map": mapping})

# ---------- node ----------
class SoftSinEnvironments:
    @classmethod
    def INPUT_TYPES(cls):
        req = {
            "format": (["weighted_parentheses", "plain", "brackets"], {"default": "weighted_parentheses"}),
            "block_weight": ("FLOAT", {"default": 1.10, "min": 0.0, "max": 2.0, "step": 0.05}),
        }
        # Inject dropdowns titled to match JSON group names (order preserved)
        for g in _GROUPS:
            req[g["key"]] = (g["opts"], {"default": NONE})
        return {
            "required": req,
            "optional": {"extras": ("STRING", {"multiline": True, "default": ""})},
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("environment_text",)
    FUNCTION = "build"
    CATEGORY = "SoftSin/Environments"

    def build(self, format, block_weight, extras="", **kwargs):
        block_weight = _sanitize_weight(block_weight, default=1.10)

        # Collect chosen named prompts from all groups
        chosen_texts = []
        for g in _GROUPS:
            sel = kwargs.get(g["key"], NONE)
            if _is_set(sel):
                txt = g["map"].get(sel, "")
                if _is_set(txt):
                    chosen_texts.append(txt)

        if not chosen_texts and not _is_set(extras):
            return ("",)

        if _is_set(extras):
            chosen_texts.append((extras or "").strip())

        core = ", ".join([t for t in chosen_texts if t])
        if not _is_set(core):
            return ("",)

        return (_wrap(core, block_weight, format),)

# ---------- registration ----------
NODE_CLASS_MAPPINGS = {"SoftSinEnvironments": SoftSinEnvironments}
NODE_DISPLAY_NAME_MAPPINGS = {"SoftSinEnvironments": "SoftSin Environments"}
