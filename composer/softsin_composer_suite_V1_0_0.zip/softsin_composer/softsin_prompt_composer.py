# softsin_prompt_composer.py
# SoftSin Prompt Composer — merges modular prompt fragments into final positive/negative text.
# Optionally encodes into CLIP condition tensors.

import re, math

_NONE_RE = re.compile(r"^\s*\(none\)\s*$", re.IGNORECASE)
EMPTIES = {"", "(none)"}

# ---------- helpers ----------
def _finite_float(x):
    try:
        v = float(x)
        if math.isfinite(v):
            return v
    except Exception:
        pass
    return None

def _strip_embedded_none(txt: str) -> str:
    """Remove '(none)', '(none:W)', or standalone 'none' — but not substrings like 'stone'."""
    if not txt:
        return ""
    txt = re.sub(r"\(\s*none\s*(?::[^)]*)?\)", "", txt, flags=re.IGNORECASE)
    txt = re.sub(r"(?<![a-z0-9_])none(?![a-z0-9_])", "", txt, flags=re.IGNORECASE)
    return txt

def _flatten_nested_weights(txt: str) -> str:
    """Collapse nested weighting, e.g., ((token:1.2):1.1) → (token:1.2)."""
    if not txt:
        return ""
    return re.sub(r"\(\(([^()]+):[0-9.]+\):[0-9.]+\)", r"(\1)", txt)

def _fix_weight_wrappers(txt: str) -> str:
    """Normalize '(token:W)' weights and kill invalid ones."""
    if not txt:
        return ""
    txt = re.sub(r"\(\s*\)", "", txt)
    txt = re.sub(r"\[\s*\]", "", txt)
    def _repl(m):
        token = m.group(1).strip()
        weight_raw = m.group(2)
        if not token or token.lower() == "none":
            return ""
        w = _finite_float(weight_raw)
        if w is None:
            return f"({token})"
        w = min(2.0, max(0.5, w))
        return f"({token}:{w:.2f})"
    return re.sub(r"\(\s*([^()]+?)\s*:\s*([^)]+?)\)", _repl, txt)

def _collapse_commas_spaces(txt: str) -> str:
    txt = re.sub(r"\s*,\s*", ", ", txt)
    txt = re.sub(r"(,\s*){2,}", ", ", txt)
    txt = re.sub(r"\s+", " ", txt).strip(", ").strip()
    return txt

def _is_effective_block(s: str) -> bool:
    if not s:
        return False
    s = s.strip()
    if not s or s in EMPTIES or _NONE_RE.match(s):
        return False
    if re.fullmatch(r"[,\s\(\)\[\]:\.]*", s):
        return False
    return True

def _sanitize_fragment(frag: str) -> str:
    if not frag:
        return ""
    t = frag.strip()
    if not t:
        return ""
    t = _strip_embedded_none(t)
    t = _flatten_nested_weights(t)
    t = _fix_weight_wrappers(t)
    t = _collapse_commas_spaces(t)
    return t.strip(", ").strip()

def _normalize(parts):
    """Final normalizer for prompt parts."""
    seen, out = set(), []
    for p in parts:
        p = _sanitize_fragment(p or "")
        if not _is_effective_block(p):
            continue
        key = p.lower()
        if key not in seen:
            seen.add(key)
            out.append(p)
    txt = ", ".join(out)
    return _collapse_commas_spaces(txt)

# ---------- node ----------
class SoftSinPromptComposer:
    """Merge modular prompt fragments into clean positive/negative strings."""

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "aged_up_weight": ("FLOAT", {"default": 1.10, "min": 1.0, "max": 4.0, "step": 0.05}),
                "base_prompt": ("STRING", {"multiline": True, "default": ""}),
                "use_safety_prefix": ("BOOLEAN", {"default": True}),
            },
            "optional": {
                "clip": ("CLIP",),
                "pose": ("STRING", {"multiline": True, "default": ""}),
                "clothing": ("STRING", {"multiline": True, "default": ""}),
                "physical_attrs": ("STRING", {"multiline": True, "default": ""}),
                "composition": ("STRING", {"multiline": True, "default": ""}),
                "lighting": ("STRING", {"multiline": True, "default": ""}),
                "environment": ("STRING", {"multiline": True, "default": ""}),
                "extras": ("STRING", {"multiline": True, "default": ""}),
                "negative_base": ("STRING", {"multiline": True, "default": ""}),
                "negative_extras": ("STRING", {"multiline": True, "default": ""}),
            }
        }

    RETURN_TYPES = ("STRING", "STRING", "CONDITION", "CONDITION")
    RETURN_NAMES  = ("text_pos", "text_neg", "cond_pos", "cond_neg")
    FUNCTION = "compose"
    CATEGORY = "SoftSin/composer node"

    def compose(self, aged_up_weight, base_prompt, use_safety_prefix=True,
                clip=None, pose="", clothing="", physical_attrs="",
                composition="", lighting="", environment="",
                extras="", negative_base="", negative_extras=""):

        W = max(1.0, float(aged_up_weight))
        safety_prefix = f"adult, (aged_up:{W:.2f})" if use_safety_prefix else ""

        text_pos = _normalize([
            safety_prefix, base_prompt, pose, clothing,
            physical_attrs, composition, lighting, environment, extras
        ])
        text_neg = _normalize([negative_base, negative_extras])

        if not text_pos and not text_neg:
            return ("", "", None, None)

        cond_pos = clip.encode(text_pos) if clip else None
        cond_neg = clip.encode(text_neg) if clip else None
        return (text_pos, text_neg, cond_pos, cond_neg)

# ---------- registration ----------
NODE_CLASS_MAPPINGS = {"SoftSinPromptComposer": SoftSinPromptComposer}
NODE_DISPLAY_NAME_MAPPINGS = {"SoftSinPromptComposer": "SoftSin Prompt Composer"}
