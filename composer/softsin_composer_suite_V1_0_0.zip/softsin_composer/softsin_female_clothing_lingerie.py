# softsin_clothing_lingerie.py
# SoftSin Clothing — Lingerie (options + optional presets)
# Reads:
#   - softsin_data/female_lingerie_options.json
#   - softsin_data/female_lingerie_presets.json  (optional; fills blanks only)
# Emits: single STRING (weighted) + optional extras

import os, re, json, math

NONE = "(none)"

# ---------- helpers ----------
def _is_set(x):
    return x not in (None, "", NONE)

def _fmt(token: str, w: float, style: str) -> str:
    token = (token or "").strip()
    if not _is_set(token):
        return ""
    if style == "plain":
        return token
    if style == "weighted_parentheses":
        return f"({token}:{w:.2f})" if abs(w - 1.0) > 1e-6 else f"({token})"
    if style == "brackets":
        return f"[{token}]"
    return token

def _wrap_block(s: str, w: float, style: str) -> str:
    s = (s or "").strip()
    if not s:
        return s
    if style == "plain" or abs(w - 1.0) < 1e-6:
        return s
    if style == "weighted_parentheses":
        return f"({s}:{w:.2f})"
    if style == "brackets":
        return f"[{s}]"
    return s

def _sanitize_weight(w: float, default=1.0, wmin=0.0, wmax=2.0):
    try:
        w = float(w)
        if not math.isfinite(w):
            return default
    except Exception:
        return default
    return max(wmin, min(wmax, w))

def _coerce_float(x, default):
    try:
        v = float(x)
        if math.isfinite(v):
            return v
    except Exception:
        pass
    return default

def _join_clean(parts):
    parts = [p.strip() for p in parts if p and str(p).strip() and str(p).strip() != NONE]
    if not parts:
        return ""
    txt = ", ".join(parts)
    txt = re.sub(r"(,\s*){2,}", ", ", txt).strip(", ").strip()
    out, seen = [], set()
    for seg in [s.strip() for s in txt.split(",")]:
        if seg and seg not in seen:
            out.append(seg); seen.add(seg)
    return ", ".join(out)

def _normalize_token(s: str) -> str:
    if not s: return ""
    if s == NONE: return NONE
    t = s.lower().replace("’", "'").replace("'", "")
    t = t.replace("-", "_")
    t = re.sub(r"\s+", "_", t.strip())
    t = re.sub(r"_+", "_", t)
    return t

def _normalize_extras(extras: str):
    out = []
    for raw in (extras or "").split(","):
        tok = _normalize_token(raw.strip())
        if tok and tok != NONE:
            out.append(tok)
    return out

def _data_dir():
    here = os.path.dirname(os.path.abspath(__file__))
    for p in [
        os.path.join(here, "softsin_data"),
        os.path.join(os.path.dirname(here), "softsin_data"),
    ]:
        if os.path.isdir(p):
            return p
    p = os.path.join(here, "softsin_data")
    os.makedirs(p, exist_ok=True)
    return p

def _load_json(filename, default):
    path = os.path.join(_data_dir(), filename)
    try:
        with open(path, "r", encoding="utf-8-sig") as f:
            return json.load(f)
    except Exception as e:
        print(f"[SoftSinFemaleLingerie] Warning: failed to load {filename}: {e}")
        return default

def _first_real_key(d):
    for k in d.keys():
        if k not in ("", NONE):
            return k
    return NONE

# ---------- load options + presets ----------
_OPTIONS = _load_json("female_lingerie_options.json", {})
_PRESETS_DOC = _load_json("female_lingerie_presets.json", {"presets": []})
_PRESETS = _PRESETS_DOC.get("presets", []) if isinstance(_PRESETS_DOC.get("presets", []), list) else []

def _opt(field):
    arr = _OPTIONS.get(field, [])
    if not isinstance(arr, list) or not arr:
        return (NONE,)
    # ensure NONE and "" are present at the top and de-duped
    out, seen = [], set()
    base = [NONE, ""]
    for x in base + arr:
        if x not in seen:
            out.append(x); seen.add(x)
    return tuple(out)

def _opt_any(*fields):
    """Try multiple keys; first non-empty list wins."""
    for field in fields:
        arr = _OPTIONS.get(field, [])
        if isinstance(arr, list) and arr:
            out, seen = [], set()
            base = [NONE, ""]
            for x in base + arr:
                if x not in seen:
                    out.append(x); seen.add(x)
            return tuple(out)
    print("[SoftSinLingerie] lace pattern list not found; tried:", fields)
    return (NONE,)

def _preset_names():
    names = [p.get("name","") for p in _PRESETS if isinstance(p, dict) and p.get("name")]
    names = [n for n in names if n not in ("", NONE)]
    return tuple([NONE] + names) if names else (NONE,)

def _preset_values(name: str):
    if not name or name == NONE:
        return {}
    for p in _PRESETS:
        if p.get("name") == name:
            return p.get("values", {}) or {}
    return {}

# ---------- emission order (exclude raw colors; handled explicitly) ----------
_EMIT_ORDER = [
    "one_piece_lingerie",
    "undergarment_top_lingerie",
    "undergarment_bottom_lingerie",
    "hosiery_lingerie",
    "accessories_lingerie",
    "materials_lingerie",
    "lace_pattern"  # canonical internal key
]

# ---------- node ----------
class SoftSinFemaleClothingLingerie:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "format": (["weighted_parentheses", "plain", "brackets"], {"default": "weighted_parentheses"}),
                "use_preset": ("BOOLEAN", {"default": False}),
                "preset": (_preset_names(), {"default": NONE}),
                "one_piece_lingerie": (_opt("one_piece_lingerie"), {"default": NONE}),
                "undergarment_top_lingerie": (_opt("undergarment_top_lingerie"), {"default": NONE}),
                "undergarment_bottom_lingerie": (_opt("undergarment_bottom_lingerie"), {"default": NONE}),
                "hosiery_lingerie": (_opt("hosiery_lingerie"), {"default": NONE}),
                "accessories_lingerie": (_opt("accessories_lingerie"), {"default": NONE}),
                "materials_lingerie": (_opt("materials_lingerie"), {"default": NONE}),
                # tolerant to both old/new keys:
                "lace_pattern": (_opt_any("lace_pattern", "lace_pattern_lingerie", "lace_patterns", "lace_styles", "lace"), {"default": NONE}),
                "color_base": (_opt("color_base"), {"default": NONE}),
                "color_trim": (_opt("color_trim"), {"default": NONE}),
                "block_weight": ("FLOAT", {"default": 1.00, "min": 0.0, "max": 2.0, "step": 0.05})
            },
            "optional": {
                "color_weight": ("STRING", {"default": ""}),  # back-compat: empty is OK
                "trim_weight":  ("STRING", {"default": ""}),  # back-compat: empty is OK
                "extras": ("STRING", {"multiline": True, "default": ""})
            }
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("lingerie_text",)
    FUNCTION = "build"
    CATEGORY = "SoftSin/Female Clothing"

    def build(self, format, use_preset, preset,
              one_piece_lingerie,
              undergarment_top_lingerie,
              undergarment_bottom_lingerie,
              hosiery_lingerie,
              accessories_lingerie,
              materials_lingerie,
              lace_pattern,
              color_base, color_trim,
              block_weight,
              color_weight="", trim_weight="",
              extras=""):

        block_weight = _sanitize_weight(block_weight)
        color_weight = _sanitize_weight(_coerce_float(color_weight, 1.15), default=1.15)
        trim_weight  = _sanitize_weight(_coerce_float(trim_weight,  1.10), default=1.10)

        if use_preset and preset != NONE:
            pv = _preset_values(preset)

            def fill(k, cur):
                return cur if _is_set(cur) else pv.get(k, cur)

            one_piece_lingerie           = fill("one_piece_lingerie", one_piece_lingerie)
            undergarment_top_lingerie    = fill("undergarment_top_lingerie", undergarment_top_lingerie)
            undergarment_bottom_lingerie = fill("undergarment_bottom_lingerie", undergarment_bottom_lingerie)
            hosiery_lingerie             = fill("hosiery_lingerie", hosiery_lingerie)
            accessories_lingerie         = fill("accessories_lingerie", accessories_lingerie)
            materials_lingerie           = fill("materials_lingerie", materials_lingerie)
            # prefer new key, fall back to old if present in preset packs
            lace_pattern                 = fill("lace_pattern", lace_pattern) or pv.get("lace_pattern_lingerie", lace_pattern)
            color_base                   = fill("color_base", color_base)
            color_trim                   = fill("color_trim", color_trim)

        # choose a primary garment for color binding (priority order)
        fields = {
            "one_piece_lingerie": one_piece_lingerie,
            "undergarment_top_lingerie": undergarment_top_lingerie,
            "undergarment_bottom_lingerie": undergarment_bottom_lingerie,
            "hosiery_lingerie": hosiery_lingerie,
            "accessories_lingerie": accessories_lingerie,
            "materials_lingerie": materials_lingerie,
            "lace_pattern": lace_pattern
        }

        primary = None
        for k in ("one_piece_lingerie", "undergarment_top_lingerie", "undergarment_bottom_lingerie"):
            v = fields.get(k, "")
            if _is_set(v):
                primary = _normalize_token(v)
                break

        # helpers to bind colors
        def _bind_base_color(color_tok, garment_tok):
            if not (_is_set(color_tok) and _is_set(garment_tok)):
                return ""
            return f"{_normalize_token(color_tok)}_{_normalize_token(garment_tok)}"

        def _trim_tok(color_tok):
            return f"{_normalize_token(color_tok)}_trim" if _is_set(color_tok) else ""

        bound_tokens = []
        if primary:
            if _is_set(color_base):
                bt = _bind_base_color(color_base, primary)
                if bt: bound_tokens.append(bt)
            if _is_set(color_trim):
                tt = _trim_tok(color_trim)
                if tt: bound_tokens.append(tt)

        # emit in deterministic order
        tokens = []

        # 1) bound color tokens first, slightly higher weight
        for bt in bound_tokens:
            tokens.append(_fmt(bt, color_weight, format))

        # 2) canonical fields (no raw colors here)
        for key in _EMIT_ORDER:
            val = fields.get(key, "")
            if _is_set(val):
                tokens.append(_fmt(_normalize_token(val), 1.05, format))

        # 3) raw color fallbacks (lower authority)
        if _is_set(color_base):
            tokens.append(_fmt(_normalize_token(color_base), 1.00, format))
        if _is_set(color_trim):
            tokens.append(_fmt(_normalize_token(color_trim), 1.00, format))

        # 4) extras
        for e in _normalize_extras(extras):
            tokens.append(_fmt(e, 1.00, format))

        core = _join_clean(tokens)
        if not core:
            return ("",)

        return (_wrap_block(core, block_weight, format),)

# ---------- registration ----------
NODE_CLASS_MAPPINGS = {"SoftSinFemaleClothingLingerie": SoftSinFemaleClothingLingerie}
NODE_DISPLAY_NAME_MAPPINGS = {"SoftSinFemaleClothingLingerie": "SoftSin Female Lingerie"}
