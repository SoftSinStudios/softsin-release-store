# softsin_image_composition.py
# SoftSin Image Composition — View/Perspective/Composition + Extended Categories
# Reads: softsin_data/image_composition.json
# Emits: single STRING (weighted) + optional extras
# Follows SoftSin structural standards (no presets)

import os, re, json, math

NONE = "(none)"

# ---------- helpers ----------
def _is_set(x):
    return x not in (None, "", NONE)

def _fmt(token: str, w: float, style: str) -> str:
    token = (token or "").strip()
    if not _is_set(token):
        return ""
    if style == "plain":
        return token
    if style == "weighted_parentheses":
        return f"({token}:{w:.2f})" if abs(w - 1.0) > 1e-6 else f"({token})"
    if style == "brackets":
        return f"[{token}]"
    return token

def _wrap_block(s: str, w: float, style: str):
    s = (s or "").strip()
    if not s:
        return s
    if style == "plain" or abs(w - 1.0) < 1e-6:
        return s
    if style == "weighted_parentheses":
        return f"({s}:{w:.2f})"
    if style == "brackets":
        return f"[{s}]"
    return s

def _sanitize_weight(w: float, default=1.0, wmin=0.0, wmax=2.0):
    try:
        w = float(w)
        if not math.isfinite(w):
            return default
    except Exception:
        return default
    return max(wmin, min(wmax, w))

def _join_clean(parts):
    parts = [p.strip() for p in parts if p and str(p).strip()]
    txt = ", ".join(parts)
    return re.sub(r"(,\s*){2,}", ", ", txt).strip(", ").strip()

def _normalize_token(s: str) -> str:
    if not s: return ""
    if s == NONE: return NONE
    t = s.lower().replace("’", "'").replace("'", "")
    t = t.replace("-", "_")
    t = re.sub(r"\s+", "_", t.strip())
    t = re.sub(r"_+", "_", t)
    return t

def _data_dir():
    here = os.path.dirname(os.path.abspath(__file__))
    for p in [
        os.path.join(here, "softsin_data"),
        os.path.join(os.path.dirname(here), "softsin_data"),
    ]:
        if os.path.isdir(p):
            return p
    p = os.path.join(here, "softsin_data")
    os.makedirs(p, exist_ok=True)
    return p

def _load_json(filename: str):
    path = os.path.join(_data_dir(), filename)
    try:
        with open(path, "r", encoding="utf-8-sig") as f:
            return json.load(f)
    except Exception as e:
        print(f"[SoftSinImageComposition] Warning: could not load {filename}: {e}")
        return {}

def _options_list(data, key):
    arr = data.get(key, [])
    if not isinstance(arr, list) or not arr:
        return (NONE,)
    seen, out = set(), []
    for x in [NONE, ""] + arr:
        if x not in seen:
            out.append(x); seen.add(x)
    return tuple(out)

def _append_token_fmt(tokens, seen_raw, token, w, fmt_style):
    raw = _normalize_token(token)
    if not _is_set(raw):
        return
    if raw in seen_raw:
        return
    tokens.append(_fmt(raw, w, fmt_style))
    seen_raw.add(raw)

# ---------- load data ----------
_DATA = _load_json("image_composition.json")

_VIEW_ANGLE_OPTS       = _options_list(_DATA, "view_angle")
_PERSPECTIVE_OPTS      = _options_list(_DATA, "perspective")
_COMPOSITION_OPTS      = _options_list(_DATA, "composition")
_FRAMING_OPTS          = _options_list(_DATA, "framing")
_FOCUS_OPTS            = _options_list(_DATA, "focus")
_CROP_OPTS             = _options_list(_DATA, "crop")
_CAMERA_EFFECT_OPTS    = _options_list(_DATA, "camera_effects")
_OVERLAY_ELEMENTS_OPTS = _options_list(_DATA, "overlay_elements")

# ---------- node ----------
class SoftSinImageComposition:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "format": (["weighted_parentheses", "plain", "brackets"], {"default": "weighted_parentheses"}),

                "view_angle": (_VIEW_ANGLE_OPTS, {"default": NONE}),
                "perspective": (_PERSPECTIVE_OPTS, {"default": NONE}),
                "composition": (_COMPOSITION_OPTS, {"default": NONE}),
                "framing": (_FRAMING_OPTS, {"default": NONE}),
                "focus": (_FOCUS_OPTS, {"default": NONE}),
                "crop": (_CROP_OPTS, {"default": NONE}),
                "camera_effects": (_CAMERA_EFFECT_OPTS, {"default": NONE}),
                "overlay_elements": (_OVERLAY_ELEMENTS_OPTS, {"default": NONE}),

                "block_weight": ("FLOAT", {"default": 1.00, "min": 0.0, "max": 2.0, "step": 0.05}),
            },
            "optional": {
                "extras": ("STRING", {"multiline": True, "default": ""}),
            },
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("composition_text",)
    FUNCTION = "build"
    CATEGORY = "SoftSin/Image Composition"

    def build(self, format, view_angle, perspective, composition,
              framing, focus, crop, camera_effects, overlay_elements,
              block_weight, extras=""):

        block_weight = _sanitize_weight(block_weight)

        tokens, seen_raw = [], set()

        # add selected options
        for choice in (
            view_angle, perspective, composition,
            framing, focus, crop, camera_effects, overlay_elements
        ):
            if _is_set(choice):
                _append_token_fmt(tokens, seen_raw, choice, 1.08, format)

        # extras
        if (extras or "").strip():
            for e in [x.strip() for x in extras.split(",") if x.strip()]:
                _append_token_fmt(tokens, seen_raw, e, 1.00, format)

        core = _join_clean(tokens)
        if not core:
            return ("",)

        return (_wrap_block(core, block_weight, format),)

# ---------- registration ----------
NODE_CLASS_MAPPINGS = {"SoftSinImageComposition": SoftSinImageComposition}
NODE_DISPLAY_NAME_MAPPINGS = {"SoftSinImageComposition": "SoftSin Image Composition"}
