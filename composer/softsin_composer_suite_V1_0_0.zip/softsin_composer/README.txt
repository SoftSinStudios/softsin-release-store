SoftSin Compositor Node Suite — README
-------------------------------------

Thank you for downloading the SoftSin Compositor Node Suite.

This package contains the official SoftSin custom nodes for ComfyUI,
along with the JSON-driven configuration library that powers them.
These nodes provide structured, modular prompt-building tools designed
to improve clarity, consistency, and creative control inside your AI
image generation workflows.

This ZIP is the official SoftSin release. You may modify your local
copy, but doing so will not match the original release signature or
the official version stored in the public repository.

-------------------------------------
CONTENTS
-------------------------------------

Root Folder:
  README.txt                  – This file
  SOFTSIN_NODE_SUITE_GUIDE.md – Full user documentation
  VERSION                     – Release version identifier

Node Files:
  *.py                        – ComfyUI node definitions

Data Files:
  softsin_data/*.json         – Neutral attribute libraries, triggers,
                                and structured environment data

-------------------------------------
INSTALLATION
-------------------------------------

1. Extract this folder.
2. Place the entire folder inside your ComfyUI installation here:

   ComfyUI/custom_nodes/SoftSin/

   Your final path should look like:

   ComfyUI/
     custom_nodes/
       SoftSin/
         environmental_attributes.py
         softsin_data/
         VERSION
         README.txt
         ...

3. Restart ComfyUI to load the nodes.

-------------------------------------
ABOUT THE NODES
-------------------------------------

The SoftSin node suite builds structured prompt components using 
JSON-based attribute libraries. These nodes do not generate images 
on their own. They output text blocks that you feed into your main 
prompt pipeline.

Design choices:
- Structured prompt building
- Neutral identifiers (first names only)
- Node-level weighting, not JSON weighting
- JSON-driven flexibility
- Predictable output behavior

Refer to SOFTSIN_NODE_SUITE_GUIDE.md for full documentation.

-------------------------------------
EDITING & CUSTOMIZATION
-------------------------------------

You may safely:
- Add new JSON entries
- Add new categories
- Create additional SoftSin-style JSON files

Avoid:
- Renaming existing keys in the JSON
- Editing the .py files unless you know Python
- Adding copyrighted or celebrity names

Your edits affect ONLY your local copy. They do not affect the 
official release or the SoftSin project.

-------------------------------------
VERSION & AUTHENTICITY
-------------------------------------

The VERSION file in this folder identifies the official release number.

This ZIP is the authentic distribution. Any repackaged or altered 
versions will not match the official release hash or metadata.

-------------------------------------
LICENSE & USE
-------------------------------------

This suite is provided for creative use inside ComfyUI. Only the ZIP distributed directly by SoftSin Studios is considered an official, trusted release. Any modified, repackaged, or altered versions are entirely unofficial and should be opened or used at your own risk. SoftSin Studios assumes no liability for any issues, damages, or misuse arising from altered or third-party distributions. Only the original release published by SoftSin Studios is supported or recognized as authentic.

-------------------------------------
SoftSin Studios
Tools for the New Creative Age
https://www.softsinstudios.com
