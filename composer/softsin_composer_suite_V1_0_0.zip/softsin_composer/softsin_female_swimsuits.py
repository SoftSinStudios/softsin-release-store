# softsin_clothing_swimsuits.py
# SoftSin Clothing — Swimsuits (options only; no presets)
# Reads:
#   - softsin_data/softsin_female_swimsuits.json
# Emits: single STRING (weighted) + optional extras
#
# Modeled after SoftSinClothingLingerie with category adjustments and color/trim binding.

import os, re, json, math

NONE = "(none)"

# ---------- helpers ----------
def _is_set(x):
    return x not in (None, "", NONE)

def _fmt(token: str, w: float, style: str) -> str:
    token = (token or "").strip()
    if not _is_set(token):
        return ""
    if style == "plain":
        return token
    if style == "weighted_parentheses":
        return f"({token}:{w:.2f})" if abs(w - 1.0) > 1e-6 else f"({token})"
    if style == "brackets":
        return f"[{token}]"
    return token

def _wrap_block(s: str, w: float, style: str) -> str:
    s = (s or "").strip()
    if not s:
        return s
    if style == "plain" or abs(w - 1.0) < 1e-6:
        return s
    if style == "weighted_parentheses":
        return f"({s}:{w:.2f})"
    if style == "brackets":
        return f"[{s}]"
    return s

def _sanitize_weight(w: float, default=1.0, wmin=0.0, wmax=2.0):
    try:
        w = float(w)
        if not math.isfinite(w):
            return default
    except Exception:
        return default
    return max(wmin, min(wmax, w))

def _coerce_float(x, default):
    try:
        v = float(x)
        if math.isfinite(v):
            return v
    except Exception:
        pass
    return default

def _join_clean(parts):
    parts = [p.strip() for p in parts if p and str(p).strip() and str(p).strip() != NONE]
    if not parts:
        return ""
    txt = ", ".join(parts)
    txt = re.sub(r"(,\s*){2,}", ", ", txt).strip(", ").strip()
    out, seen = [], set()
    for seg in [s.strip() for s in txt.split(",")]:
        if seg and seg not in seen:
            out.append(seg); seen.add(seg)
    return ", ".join(out)

def _normalize_token(s: str) -> str:
    if not s: return ""
    if s == NONE: return NONE
    t = s.lower().replace("’", "'").replace("'", "")
    t = t.replace("-", "_")
    t = re.sub(r"\s+", "_", t.strip())
    t = re.sub(r"_+", "_", t)
    return t

def _normalize_extras(extras: str):
    out = []
    for raw in (extras or "").split(","):
        tok = _normalize_token(raw.strip())
        if tok and tok != NONE:
            out.append(tok)
    return out

def _data_dir():
    here = os.path.dirname(os.path.abspath(__file__))
    for p in [
        os.path.join(here, "softsin_data"),
        os.path.join(os.path.dirname(here), "softsin_data"),
    ]:
        if os.path.isdir(p):
            return p
    p = os.path.join(here, "softsin_data")
    os.makedirs(p, exist_ok=True)
    return p

def _load_json(filename, default):
    path = os.path.join(_data_dir(), filename)
    try:
        with open(path, "r", encoding="utf-8-sig") as f:
            return json.load(f)
    except Exception as e:
        print(f"[SoftSinFemaleSwimsuits] Warning: failed to load {filename}: {e}")
        return default

# ---------- load options (no presets) ----------
# Expected shape in softsin_swimsuits.json:
# {
#   "one_piece": [...],
#   "two_piece": [...],
#   "sport_race_swim": [...],
#   "coverups": [...],
#   "materials": [...],
#   "color_base": [...],
#   "color_trim": [...]
# }
_OPTIONS = _load_json("female_swimsuits.json", {})

def _opt(field):
    arr = _OPTIONS.get(field, [])
    if not isinstance(arr, list) or not arr:
        return (NONE,)
    out, seen = [], set()
    base = [NONE, ""]
    for x in base + arr:
        if x not in seen:
            out.append(x); seen.add(x)
    return tuple(out)

# emission order
_EMIT_ORDER = [
    "one_piece",
    "two_piece",
    "sport_race_swim",
    "coverups",
    "materials"
]

# ---------- node ----------
class SoftSinFemaleSwimsuits:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "format": (["weighted_parentheses", "plain", "brackets"], {"default": "weighted_parentheses"}),
                "one_piece": (_opt("one_piece"), {"default": NONE}),
                "two_piece": (_opt("two_piece"), {"default": NONE}),
                "sport_race_swim": (_opt("sport_race_swim"), {"default": NONE}),
                "coverups": (_opt("coverups"), {"default": NONE}),
                "materials": (_opt("materials"), {"default": NONE}),
                "color_base": (_opt("color_base"), {"default": NONE}),
                "color_trim": (_opt("color_trim"), {"default": NONE}),
                "block_weight": ("FLOAT", {"default": 1.00, "min": 0.0, "max": 2.0, "step": 0.05})
            },
            "optional": {
                "color_weight": ("STRING", {"default": ""}),
                "trim_weight": ("STRING", {"default": ""}),
                "extras": ("STRING", {"multiline": True, "default": ""})
            }
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("swimsuits_text",)
    FUNCTION = "build"
    CATEGORY = "SoftSin/Female Clothing"

    def build(self, format,
              one_piece, two_piece, sport_race_swim, coverups,
              materials, color_base, color_trim,
              block_weight,
              color_weight="", trim_weight="",
              extras=""):

        block_weight = _sanitize_weight(block_weight)
        color_weight = _sanitize_weight(_coerce_float(color_weight, 1.15), default=1.15)
        trim_weight  = _sanitize_weight(_coerce_float(trim_weight, 1.10), default=1.10)

        # choose a primary garment for color binding (priority order)
        fields = {
            "one_piece": one_piece,
            "two_piece": two_piece,
            "sport_race_swim": sport_race_swim,
            "coverups": coverups,
            "materials": materials
        }

        primary = None
        for k in ("one_piece", "two_piece", "sport_race_swim"):
            v = fields.get(k, "")
            if _is_set(v):
                primary = _normalize_token(v)
                break

        def _bind_base_color(color_tok, garment_tok):
            if not (_is_set(color_tok) and _is_set(garment_tok)):
                return ""
            return f"{_normalize_token(color_tok)}_{_normalize_token(garment_tok)}"

        def _trim_tok(color_tok):
            return f"{_normalize_token(color_tok)}_trim" if _is_set(color_tok) else ""

        bound_tokens = []
        if primary:
            if _is_set(color_base):
                bt = _bind_base_color(color_base, primary)
                if bt: bound_tokens.append(bt)
            if _is_set(color_trim):
                tt = _trim_tok(color_trim)
                if tt: bound_tokens.append(tt)

        tokens = []

        # 1) bound color tokens first
        for bt in bound_tokens:
            tokens.append(_fmt(bt, color_weight, format))

        # 2) canonical fields: garments + materials
        for key in _EMIT_ORDER:
            val = fields.get(key, "")
            if _is_set(val):
                tokens.append(_fmt(_normalize_token(val), 1.05, format))

        # 3) raw color fallbacks
        if _is_set(color_base):
            tokens.append(_fmt(_normalize_token(color_base), 1.00, format))
        if _is_set(color_trim):
            tokens.append(_fmt(_normalize_token(color_trim), 1.00, format))

        # 4) extras
        for e in _normalize_extras(extras):
            tokens.append(_fmt(e, 1.00, format))

        core = _join_clean(tokens)
        if not core:
            return ("",)

        return (_wrap_block(core, block_weight, format),)

# ---------- registration ----------
NODE_CLASS_MAPPINGS = {"SoftSinFemaleSwimsuits": SoftSinFemaleSwimsuits}
NODE_DISPLAY_NAME_MAPPINGS = {"SoftSinFemaleSwimsuits": "SoftSin Female Swimsuits"}
