# custom_nodes/softsin_composer/__init__.py
import importlib, pkgutil, sys, traceback

NODE_CLASS_MAPPINGS = {}
NODE_DISPLAY_NAME_MAPPINGS = {}

def _merge(mod):
    m1 = getattr(mod, "NODE_CLASS_MAPPINGS", None)
    m2 = getattr(mod, "NODE_DISPLAY_NAME_MAPPINGS", None)
    if isinstance(m1, dict): NODE_CLASS_MAPPINGS.update(m1)
    if isinstance(m2, dict): NODE_DISPLAY_NAME_MAPPINGS.update(m2)

# auto-import all softsin_*.py in this package (except __init__)
for modinfo in pkgutil.iter_modules(__path__):
    name = modinfo.name
    if not name.startswith("softsin_"):
        continue
    try:
        mod = importlib.import_module(f".{name}", __name__)
        _merge(mod)
    except Exception as e:
        print(f"[softsin_composer] Failed to import {name}: {e}", file=sys.stderr)
        traceback.print_exc()
