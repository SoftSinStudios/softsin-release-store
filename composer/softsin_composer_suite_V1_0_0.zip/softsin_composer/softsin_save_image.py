# softsin_save_image.py
# SoftSin Save Image — only embed what you want (no prompt/workflow unless toggled)
# Detects BOTH samplers:
# - KSampler (Preview): the sampler feeding any PreviewImage chain
# - KSampler: the sampler feeding THIS (single) SaveImage node
# Prints Preview first, then Final.
# Filters out prompt/workflow by default; allowlist extras via pass_keys.

import os, re, glob, json
import numpy as np
import torch
from PIL import Image
from PIL.PngImagePlugin import PngInfo

try:
    from nodes import folder_paths, args  # ComfyUI portable embed
except Exception:
    import folder_paths
    class _Args: disable_metadata = False
    args = _Args()

SAFE = re.compile(r"[^a-zA-Z0-9_\-\.]+")
_INDEX_RE = re.compile(r"^(?P<prefix>.+)_(?P<idx>\d{5})\.png$", re.IGNORECASE)

def _safe(s: str) -> str:
    s = (s or "SoftSin").strip().replace(" ", "_")
    return SAFE.sub("_", s)

def _to_pil(img) -> Image.Image:
    if isinstance(img, Image.Image):
        return img
    if isinstance(img, torch.Tensor):
        a = img.detach().cpu().numpy()
    else:
        a = np.asarray(img)
    if a.ndim == 4 and a.shape[0] == 1:
        a = a[0]
    if a.dtype.kind == "f":
        a = np.clip(a, 0.0, 1.0)
        a = (a * 255.0).astype(np.uint8)
    else:
        a = np.clip(a, 0, 255).astype(np.uint8)
    return Image.fromarray(a)

def _next_start_index(outdir: str, prefix: str) -> int:
    pat = os.path.join(outdir, f"{prefix}_*.png")
    max_idx = -1
    for path in glob.glob(pat):
        name = os.path.basename(path)
        m = _INDEX_RE.match(name)
        if m:
            try:
                i = int(m.group("idx"))
                if i > max_idx:
                    max_idx = i
            except ValueError:
                pass
    return max_idx + 1

# -------------------- graph helpers --------------------

def _parse_prompt_obj(prompt):
    if isinstance(prompt, dict):
        return prompt
    try:
        return json.loads(prompt)
    except Exception:
        return None

def _find_single_save_node_id(p: dict):
    """Return the id of the only Save node (SoftSinSaveImage or SaveImage)."""
    cand = None
    for nid, node in p.items():
        if node.get("class_type") in ("SoftSinSaveImage", "SaveImage"):
            if cand is not None:
                # More than one — bail to avoid ambiguity
                return None
            cand = nid
    return cand

def _node_input_ref(node: dict, input_name: str):
    """Return [node_id, slot] ref from node.inputs[input_name] if in that form."""
    if not isinstance(node, dict):
        return None
    ins = node.get("inputs", {})
    ref = ins.get(input_name)
    if isinstance(ref, list) and len(ref) >= 1 and isinstance(ref[0], str):
        return ref
    return None

def _resolve_ksampler_for_save(p: dict, save_id: str):
    """Follow save 'image' -> VAEDecode -> 'samples' -> KSampler, return (ksampler_id, params)."""
    if not save_id or save_id not in p:
        return None, None
    save_node = p[save_id]
    img_ref = _node_input_ref(save_node, "image")
    if not img_ref:
        return None, None
    vae_id = img_ref[0]
    vae = p.get(vae_id)
    if not vae or vae.get("class_type") != "VAEDecode":
        return None, None
    samp_ref = _node_input_ref(vae, "samples")
    if not samp_ref:
        return None, None
    ks_id = samp_ref[0]
    ks_node = p.get(ks_id)
    if not ks_node or ks_node.get("class_type") != "KSampler":
        return None, None
    ins = ks_node.get("inputs", {})
    return ks_id, {
        "seed": ins.get("seed", ""),
        "steps": ins.get("steps", ""),
        "cfg": ins.get("cfg", ""),
        "sampler_name": ins.get("sampler_name", ""),
        "scheduler": ins.get("scheduler", ""),
        "denoise": ins.get("denoise", ""),
    }

def _resolve_preview_ksampler(p: dict, exclude_ks_id: str | None):
    """Find a KSampler feeding any PreviewImage chain; prefer one not equal to exclude_ks_id."""
    if not isinstance(p, dict):
        return None, None
    candidates = []
    for nid, node in p.items():
        if node.get("class_type") == "PreviewImage":
            img_ref = _node_input_ref(node, "images")
            if not img_ref:
                continue
            vae_id = img_ref[0]
            vae = p.get(vae_id)
            if not vae or vae.get("class_type") != "VAEDecode":
                continue
            samp_ref = _node_input_ref(vae, "samples")
            if not samp_ref:
                continue
            ks_id = samp_ref[0]
            ks_node = p.get(ks_id)
            if ks_node and ks_node.get("class_type") == "KSampler":
                candidates.append(ks_id)
    chosen = None
    for c in candidates:
        if c != exclude_ks_id:
            chosen = c
            break
    if not chosen and candidates:
        chosen = candidates[0]
    if not chosen:
        return None, None
    ins = p[chosen].get("inputs", {})
    return chosen, {
        "seed": ins.get("seed", ""),
        "steps": ins.get("steps", ""),
        "cfg": ins.get("cfg", ""),
        "sampler_name": ins.get("sampler_name", ""),
        "scheduler": ins.get("scheduler", ""),
        "denoise": ins.get("denoise", ""),
    }

# -------------------- formatting --------------------

def _format_ksampler_section(title: str, ks: dict | None):
    if not ks:
        return []
    lines = [title]
    first = []
    seed  = str(ks.get("seed", "") or "")
    steps = str(ks.get("steps", "") or "")
    cfg   = str(ks.get("cfg", "") or "")
    sname = str(ks.get("sampler_name", "") or "")
    sched = str(ks.get("scheduler", "") or "")
    dnoi  = str(ks.get("denoise", "") or "")
    if seed:  first.append(f" Seed: {seed}")
    if steps: first.append(f"  Steps: {steps}")
    if first: lines.append("".join(first))
    if cfg:   lines.append(f" CFG: {cfg}")
    if sname: lines.append(f" Sampler Name: {sname}")
    if sched: lines.append(f" Scheduler: {sched}")
    if dnoi:  lines.append(f" Denoise: {dnoi}")
    lines.append("")  # spacer
    return lines

def _format_softsin_block(base_text: str,
                          ks_preview: dict | None,
                          ks_final: dict | None) -> str:
    import re as _re
    lines = [l for l in (base_text or "").splitlines()]

    # Insert KSampler (Preview) first, then KSampler (final)
    prev_lines = _format_ksampler_section("KSampler (Preview):", ks_preview)
    final_lines = _format_ksampler_section("KSampler:", ks_final)
    if prev_lines:
        lines.append("")
        lines.extend(prev_lines)
    if final_lines:
        lines.extend(final_lines)

    text = "\n".join(lines)
    text = _re.sub(r"\n{3,}", "\n\n", text).strip()
    # enforce two blank lines above and below
    text = "\n\n" + text
    if not text.endswith("\n\n"):
        text += "\n\n"
    return text

# -------------------- allowlisted metadata build --------------------

def _build_pnginfo(visible_dict, hidden_dict, prompt,
                   include_prompt=False, include_workflow=False,
                   pass_keys=None):
    """Only write allowlisted keys; never write prompt/workflow unless toggled."""
    if args and getattr(args, "disable_metadata", False):
        return None, "", None, None, None

    # Build allowlist
    allow = {"SoftSin-Metadata"}
    if pass_keys:
        try:
            for k in str(pass_keys).split(","):
                k = k.strip()
                if k:
                    allow.add(k)
        except Exception:
            pass
    if include_workflow:
        allow.add("workflow")

    pnginfo = PngInfo()

    # Write only allowed keys from hidden/visible dicts, excluding SoftSin-Metadata for now
    def _write_dict(d):
        if not isinstance(d, dict):
            return
        for k, v in d.items():
            k = str(k)
            if v is None or k == "SoftSin-Metadata" or k not in allow:
                continue
            try:
                pnginfo.add_text(k, json.dumps(v))
            except Exception:
                pnginfo.add_text(k, str(v))

    _write_dict(hidden_dict)
    _write_dict(visible_dict)

    # Base SoftSin text (visible overrides hidden)
    base_text = ""
    if isinstance(hidden_dict, dict) and "SoftSin-Metadata" in hidden_dict:
        base_text = str(hidden_dict["SoftSin-Metadata"])
    if isinstance(visible_dict, dict) and "SoftSin-Metadata" in visible_dict:
        base_text = str(visible_dict["SoftSin-Metadata"]) or base_text

    # Parse prompt; resolve BOTH samplers (no Random Dimensions anywhere)
    ks_final = None
    ks_preview = None
    p = _parse_prompt_obj(prompt)
    if p:
        save_id = _find_single_save_node_id(p)
        final_id, ks_final = _resolve_ksampler_for_save(p, save_id)
        _, ks_preview = _resolve_preview_ksampler(p, exclude_ks_id=final_id)

        if include_prompt:
            try:
                pnginfo.add_text("prompt", json.dumps(p))
            except Exception:
                pnginfo.add_text("prompt", str(p))

    def _add_softsin_metadata(text):
        pnginfo.add_text("SoftSin-Metadata", text)

    return pnginfo, base_text, ks_preview, ks_final, _add_softsin_metadata

class SoftSinSaveImage:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "image": ("IMAGE",),
                "filename_prefix": ("STRING", {"default": "SoftSin"}),
            },
            "optional": {
                "extra_pnginfo": ("DICT", {}),
                "subfolder": ("STRING", {"default": ""}),
                # controls
                "include_prompt": ("BOOL", {"default": False}),
                "include_workflow": ("BOOL", {"default": False}),
                "pass_keys": ("STRING", {"default": ""}),   # comma-separated allowlist extras
            },
            "hidden": {
                "prompt": "PROMPT",
                "extra_pnginfo_hidden": "EXTRA_PNGINFO",
            },
        }

    RETURN_TYPES = ()
    FUNCTION = "save"
    CATEGORY = "SoftSin/Utilities"
    OUTPUT_NODE = True

    def save(self, image, filename_prefix, extra_pnginfo=None, subfolder="",
             include_prompt=False, include_workflow=False, pass_keys="",
             prompt=None, extra_pnginfo_hidden=None):
        base_out = folder_paths.get_output_directory()
        if subfolder:
            base_out = os.path.join(base_out, _safe(subfolder))
        os.makedirs(base_out, exist_ok=True)
        prefix = _safe(filename_prefix)

        pnginfo, base_text, ks_preview, ks_final, add_softsin_text = _build_pnginfo(
            extra_pnginfo, extra_pnginfo_hidden, prompt,
            include_prompt=include_prompt,
            include_workflow=include_workflow,
            pass_keys=pass_keys
        )

        start = _next_start_index(base_out, prefix)

        for i, img in enumerate(image):
            pil = _to_pil(img)

            if pnginfo is not None:
                final_text = _format_softsin_block(
                    base_text,
                    ks_preview=ks_preview,
                    ks_final=ks_final
                )
                add_softsin_text(final_text)

            path = os.path.join(base_out, f"{prefix}_{start + i:05d}.png")
            if pnginfo is not None:
                pil.save(path, pnginfo=pnginfo, compress_level=6, optimize=False)
            else:
                pil.save(path, compress_level=6, optimize=False)

        return ()

# Register node
NODE_CLASS_MAPPINGS = {"SoftSinSaveImage": SoftSinSaveImage}
NODE_DISPLAY_NAME_MAPPINGS = {"SoftSinSaveImage": "SoftSin Save Image"}
