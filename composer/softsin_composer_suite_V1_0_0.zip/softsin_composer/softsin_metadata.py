# softsin_metadata.py
# SoftSin Metadata — formats a human readable metadata block for PNGInfo
# Adds dual-sampler reporting:
#   KSampler - no upscale  (A)
#   KSampler upscaled      (B)
#
# Inputs:
#   required:
#     - artist_name (STRING)
#     - copyright_year (STRING)
#   optional:
#     - orientation (STRING)                 # fallback if randdim_params not provided
#     - size_str (STRING)                    # fallback if randdim_params not provided
#     - ksamplerA_params (DICT)              # {seed, steps, cfg, sampler_name, scheduler, denoise}
#     - ksamplerB_params (DICT)              # {seed, steps, cfg, sampler_name, scheduler, denoise}
#     - randdim_params (DICT)                # {seed, orientation, width, height}
# Output:
#   - extra_pnginfo (DICT) with key "SoftSin-Metadata"

import re

def _get(d, key):
    if not isinstance(d, dict):
        return ""
    v = d.get(key, "")
    return "" if v is None else str(v)

def _clean(s):
    # normalize internal spacing, then enforce two blank lines at start and end
    s = str(s or "").replace("\r\n", "\n").replace("\r", "\n")
    s = re.sub(r"\n{3,}", "\n\n", s).strip()
    s = "\n\n" + s  # two leading blank lines
    if not s.endswith("\n\n"):
        s += "\n\n"  # two trailing blank lines
    return s

def _append_if(lines, label, value, prefix=" "):
    v = (value or "").strip()
    if v:
        lines.append(f"{prefix}{label}{v}")

def _ksampler_block(title, params):
    """Build a sampler block with fields only if present. Returns list[str] or []."""
    if not isinstance(params, dict) or not params:
        return []

    out = [title]
    # First line tries to keep Seed and Steps together
    seed  = _get(params, "seed")
    steps = _get(params, "steps")
    first_line = ""
    if seed:
        first_line = f" Seed: {seed}"
    if steps:
        if first_line:
            first_line += f"  Steps: {steps}"
        else:
            first_line = f" Steps: {steps}"
    if first_line:
        out.append(first_line)

    _append_if(out, "CFG: ",          _get(params, "cfg"))
    _append_if(out, "Sampler Name: ", _get(params, "sampler_name"))
    _append_if(out, "Scheduler: ",    _get(params, "scheduler"))
    _append_if(out, "Denoise: ",      _get(params, "denoise"))
    out.append("")  # spacer after the block
    return out

class SoftSinMetadata:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "artist_name": ("STRING", {"default": "Enter Name Here"}),
                "copyright_year": ("STRING", {"default": "2025"}),
            },
            "optional": {
                "orientation": ("STRING", {"default": ""}),   # legacy fallback
                "size_str": ("STRING", {"default": ""}),       # legacy fallback
                "ksamplerA_params": ("DICT", {}),              # preview/no-upscale branch
                "ksamplerB_params": ("DICT", {}),              # final/upscaled branch
                "randdim_params": ("DICT", {}),                # optional packed dict
            },
        }

    RETURN_TYPES = ("DICT",)
    RETURN_NAMES = ("extra_pnginfo",)
    FUNCTION = "build"
    CATEGORY = "SoftSin/Utilities"

    def build(self, artist_name, copyright_year,
              orientation="", size_str="",
              ksamplerA_params=None, ksamplerB_params=None, randdim_params=None):

        kpA = ksamplerA_params or {}
        kpB = ksamplerB_params or {}
        rp  = randdim_params or {}

        # ---------- KSampler blocks (A above B) ----------
        kA_lines = _ksampler_block("KSampler - no upscale:", kpA)
        kB_lines = _ksampler_block("KSampler upscaled:",     kpB)

        # ---------- Random Dimensions (only include present fields) ----------
        r_seed   = _get(rp, "seed")
        r_orient = (_get(rp, "orientation") or orientation or "").strip()
        r_w = _get(rp, "width")
        r_h = _get(rp, "height")
        dims_text = ""
        if r_w and r_h:
            dims_text = f"{r_w} x {r_h}"
        elif size_str.strip():
            dims_text = size_str.strip()

        r_lines = []
        _append_if(r_lines, "Seed: ",        r_seed)
        _append_if(r_lines, "Orientation: ", r_orient)
        if dims_text:
            label = (r_orient.lower() + " Dimensions: ") if r_orient else "Dimensions: "
            r_lines.append(f" {label}{dims_text}")
        if r_lines:
            r_lines.append("")

        # ---------- Assemble ----------
        lines = [f"Artist: {artist_name}, © {copyright_year} {artist_name}", ""]
        # A (no-upscale) first, then B (upscaled)
        if kA_lines:
            lines.extend(kA_lines)
        if kB_lines:
            lines.extend(kB_lines)

        if r_lines:
            lines.append("SoftSin Random Dimensions Node:")
            lines.extend(r_lines)

        # Constant footer (unchanged)
        lines.extend([
            'Note1: all models are 25 years or older and age is auto-controlled by hardcoded "adult" and "aged_up: >= 1.0" weighting via the SoftSin Composer Suite.',
            "",
            "Note2: all models are fictitious and any likeness to real people is coincidental and not intended.",
            "",
            "Website: https://www.softsinstudios.com",
            "",
            "Socials:",
            "Facebook: https://www.facebook.com/softsinstudios",
            "DeviantArt: https://www.deviantart.com/softsinstudios",
            "",
            "Warning: Only copies downloaded directly from https://www.softsinstudios.com are verified and authentic.",
            "Versions obtained elsewhere are not genuine. SoftSin Studios assumes no responsibility for the integrity, functionality, or safety of unauthorized or modified distributions of the SoftSin Composer Node Suite.",
        ])

        formatted_text = _clean("\n".join(lines))
        return ({"SoftSin-Metadata": formatted_text},)

NODE_CLASS_MAPPINGS = {"SoftSinMetadata": SoftSinMetadata}
NODE_DISPLAY_NAME_MAPPINGS = {"SoftSinMetadata": "SoftSin Metadata"}
