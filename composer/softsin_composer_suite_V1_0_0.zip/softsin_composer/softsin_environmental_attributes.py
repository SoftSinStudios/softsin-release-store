import os, json, re, math

NONE = "(none)"

# ---------- utils ----------

def _is_set(x):
    return x not in (None, "", NONE)

def _fmt(token: str, w: float, style: str) -> str:
    token = (token or "").strip()
    if not _is_set(token):
        return ""
    if style == "plain":
        return token
    if style == "weighted_parentheses":
        return f"({token}:{w:.2f})" if abs(w - 1.0) > 1e-6 else f"({token})"
    if style == "brackets":
        return f"[{token}]"
    return token

def _wrap_block(s: str, w: float, style: str) -> str:
    s = (s or "").strip()
    if not s:
        return s
    if style == "plain" or abs(w - 1.0) < 1e-6:
        return s
    if style == "weighted_parentheses":
        return f"({s}:{w:.2f})"
    if style == "brackets":
        return f"[{s}]"
    return s

def _join_clean(parts):
    parts = [p.strip() for p in parts if p and p.strip() and p.strip() != NONE]
    txt = ", ".join(parts)
    return re.sub(r"(,\s*){2,}", ", ", txt).strip(", ").strip()

def _data_dir():
    here = os.path.dirname(os.path.abspath(__file__))
    for p in [
        os.path.join(here, "softsin_data"),
        os.path.join(os.path.dirname(here), "softsin_data"),
    ]:
        if os.path.isdir(p):
            return p
    # fallback: create local softsin_data
    p = os.path.join(here, "softsin_data")
    os.makedirs(p, exist_ok=True)
    return p

def _load_json(filename, default):
    path = os.path.join(_data_dir(), filename)
    try:
        with open(path, "r", encoding="utf-8-sig") as f:
            return json.load(f)
    except Exception as e:
        print(f"[SoftSinEnvironmentalAttributes] Warning: failed to load {filename}: {e}")
        return default

def _sanitize_weight(w: float, default=1.0, wmin=0.0, wmax=2.0):
    try:
        w = float(w)
        if not math.isfinite(w):
            return default
    except Exception:
        return default
    return max(wmin, min(wmax, w))

def _opt_from_map(m: dict):
    keys = list(m.keys()) if isinstance(m, dict) else []
    ordered = [NONE] + [k for k in keys if k not in (NONE, "")]
    return tuple(ordered or [NONE])

def _apply_map(m: dict, key: str) -> str:
    if not _is_set(key):
        return ""
    if not isinstance(m, dict):
        return key
    if key in (NONE, ""):
        return ""
    return m.get(key, key)

def _opt_from_list(arr):
    arr = list(arr) if isinstance(arr, list) else []
    out = [NONE] + [x for x in arr if x not in (NONE, "")]
    seen, dedup = set(), []
    for x in out:
        if x not in seen:
            dedup.append(x)
            seen.add(x)
    return tuple(dedup or [NONE])

# ---------- load schema ----------

_DEFAULT = {
    "region_macro_map": {},
    "terrain_map": {},
    "biome_map": {},
    "canopy_map": {},
    "undergrowth_map": {},
    "water_bodies": [],
    "ground_surface_map": {},
    "landform_features": [],
    "sky_state": [],
    "weather_state": [],
    "season": [],
    "atmospheric_elements": [],
    "manmade_presence": [],
    "clutter_details": []
}

# NOTE: this matches your actual JSON filename: Environmental_attributes.json
_DOC = _load_json("Environmental_attributes.json", _DEFAULT)

# ---------- derive UI choices ----------

REGION_MACRO_KEYS         = _opt_from_map(_DOC.get("region_macro_map", {}))
TERRAIN_KEYS              = _opt_from_map(_DOC.get("terrain_map", {}))
BIOME_KEYS                = _opt_from_map(_DOC.get("biome_map", {}))
CANOPY_KEYS               = _opt_from_map(_DOC.get("canopy_map", {}))
UNDERGROWTH_KEYS          = _opt_from_map(_DOC.get("undergrowth_map", {}))
WATER_BODY_KEYS           = _opt_from_list(_DOC.get("water_bodies", []))
GROUND_SURFACE_KEYS       = _opt_from_map(_DOC.get("ground_surface_map", {}))
LANDFORM_FEATURE_KEYS     = _opt_from_list(_DOC.get("landform_features", []))
SKY_STATE_KEYS            = _opt_from_list(_DOC.get("sky_state", []))
WEATHER_STATE_KEYS        = _opt_from_list(_DOC.get("weather_state", []))
SEASON_KEYS               = _opt_from_list(_DOC.get("season", []))
ATMOSPHERIC_ELEMENTS_KEYS = _opt_from_list(_DOC.get("atmospheric_elements", []))
MANMADE_PRESENCE_KEYS     = _opt_from_list(_DOC.get("manmade_presence", []))
CLUTTER_DETAILS_KEYS      = _opt_from_list(_DOC.get("clutter_details", []))

# ---------- node ----------

class SoftSinEnvironmentalAttributes:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "format": (
                    ("weighted_parentheses", "plain", "brackets"),
                    {"default": "weighted_parentheses"}
                ),
                "region_macro":   (REGION_MACRO_KEYS,         {"default": NONE}),
                "terrain":        (TERRAIN_KEYS,              {"default": NONE}),
                "biome":          (BIOME_KEYS,                {"default": NONE}),
                "canopy":         (CANOPY_KEYS,               {"default": NONE}),
                "undergrowth":    (UNDERGROWTH_KEYS,          {"default": NONE}),
                "water_body":     (WATER_BODY_KEYS,           {"default": NONE}),
                "ground_surface": (GROUND_SURFACE_KEYS,       {"default": NONE}),
                "landform_feature": (LANDFORM_FEATURE_KEYS,   {"default": NONE}),
                "sky_state":      (SKY_STATE_KEYS,            {"default": NONE}),
                "weather_state":  (WEATHER_STATE_KEYS,        {"default": NONE}),
                "season":         (SEASON_KEYS,               {"default": NONE}),
                "atmospheric_elements": (ATMOSPHERIC_ELEMENTS_KEYS, {"default": NONE}),
                "manmade_presence": (MANMADE_PRESENCE_KEYS,   {"default": NONE}),
                "clutter_details": (CLUTTER_DETAILS_KEYS,     {"default": NONE}),
                "block_weight": (
                    "FLOAT",
                    {"default": 1.00, "min": 0.0, "max": 2.0, "step": 0.05}
                ),
            },
            "optional": {
                "extras": ("STRING", {"multiline": True, "default": ""})
            }
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("environment_text",)
    FUNCTION = "build"
    CATEGORY = "SoftSin/Environments"

    def build(self, format,
              region_macro, terrain, biome, canopy, undergrowth,
              water_body, ground_surface, landform_feature,
              sky_state, weather_state, season,
              atmospheric_elements, manmade_presence, clutter_details,
              block_weight, extras=""):

        block_weight = _sanitize_weight(block_weight)

        parts = [
            _fmt(_apply_map(_DOC.get("region_macro_map", {}),   region_macro),   1.0, format),
            _fmt(_apply_map(_DOC.get("terrain_map", {}),        terrain),        1.0, format),
            _fmt(_apply_map(_DOC.get("biome_map", {}),          biome),          1.0, format),
            _fmt(_apply_map(_DOC.get("canopy_map", {}),         canopy),         1.0, format),
            _fmt(_apply_map(_DOC.get("undergrowth_map", {}),    undergrowth),    1.0, format),
            _fmt(water_body,                                    1.0,             format),
            _fmt(_apply_map(_DOC.get("ground_surface_map", {}), ground_surface), 1.0, format),
            _fmt(landform_feature,                              1.0,             format),
            _fmt(sky_state,                                     1.0,             format),
            _fmt(weather_state,                                 1.0,             format),
            _fmt(season,                                        1.0,             format),
            _fmt(atmospheric_elements,                          1.0,             format),
            _fmt(manmade_presence,                              1.0,             format),
            _fmt(clutter_details,                               1.0,             format),
        ]

        if extras.strip():
            parts.append(extras.strip())

        phrase = _join_clean(parts)
        if not phrase:
            return ("",)

        return (_wrap_block(phrase, block_weight, format),)

# ---- Comfy registration ----

NODE_CLASS_MAPPINGS = {
    "SoftSinEnvironmentalAttributes": SoftSinEnvironmentalAttributes
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "SoftSinEnvironmentalAttributes": "SoftSin Environmental Attributes"
}
