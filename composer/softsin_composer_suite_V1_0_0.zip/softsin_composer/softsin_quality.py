# softsin_quality.py
# SoftSin Quality — one node, 7-pick, no presets
# Reads: softsin_data/softsin_quality.json
# Emits: single STRING (weighted) + optional extras
# UI order: format → quality_1..quality_7 → block_weight → extras

import os, re, json, math

NONE = "(none)"

# ---------- helpers ----------
def _is_set(x):
    return x not in (None, "", NONE)

def _fmt(token: str, w: float, style: str) -> str:
    token = (token or "").strip()
    if not _is_set(token):
        return ""
    if style == "plain":
        return token
    if style == "weighted_parentheses":
        return f"({token}:{w:.2f})" if abs(w - 1.0) > 1e-6 else f"({token})"
    if style == "brackets":
        return f"[{token}]"
    return token

def _wrap_block(s: str, w: float, style: str) -> str:
    s = (s or "").strip()
    if not s:
        return s
    if style == "plain" or abs(w - 1.0) < 1e-6:
        return s
    if style == "weighted_parentheses":
        return f"({s}:{w:.2f})"
    if style == "brackets":
        return f"[{s}]"
    return s

def _sanitize_weight(w: float, default=1.0, wmin=0.0, wmax=2.0):
    try:
        w = float(w)
        if not math.isfinite(w):
            return default
    except Exception:
        return default
    return max(wmin, min(wmax, w))

def _join_clean(parts):
    parts = [p.strip() for p in parts if p and str(p).strip() and str(p).strip() != NONE]
    if not parts:
        return ""
    txt = ", ".join(parts)
    txt = re.sub(r"(,\s*){2,}", ", ", txt).strip(", ").strip()
    out, seen = [], set()
    for seg in [s.strip() for s in txt.split(",")]:
        if seg and seg not in seen:
            out.append(seg); seen.add(seg)
    return ", ".join(out)

def _normalize_token(s: str) -> str:
    if not s: return ""
    if s == NONE: return NONE
    t = s.lower().replace("’", "'").replace("'", "")
    t = t.replace("-", "_")
    t = re.sub(r"\s+", "_", t.strip())
    t = re.sub(r"_+", "_", t)
    return t

def _normalize_list(arr):
    out = []
    for x in (arr or []):
        tok = _normalize_token(str(x))
        if tok and tok != NONE:
            out.append(tok)
    return out

def _normalize_extras(extras: str):
    out = []
    for raw in (extras or "").split(","):
        tok = _normalize_token(raw.strip())
        if tok and tok != NONE:
            out.append(tok)
    return out

def _data_dir():
    here = os.path.dirname(os.path.abspath(__file__))
    for p in [
        os.path.join(here, "softsin_data"),
        os.path.join(os.path.dirname(here), "softsin_data"),
    ]:
        if os.path.isdir(p):
            return p
    p = os.path.join(here, "softsin_data")
    os.makedirs(p, exist_ok=True)
    return p

def _load_json(filename, default):
    path = os.path.join(_data_dir(), filename)
    try:
        with open(path, "r", encoding="utf-8-sig") as f:
            obj = json.load(f)
        return obj if isinstance(obj, dict) else default
    except Exception as e:
        print(f"[SoftSinQuality] Warning: failed to load {filename}: {e}")
        return default

# ---------- data ----------
# Shape: { "scores": [...], "core": [...], "extended": [...], "effects": [...] }
_RAW = _load_json("softsin_quality.json", {"scores": [], "core": [], "extended": [], "effects": []})

# Keep these even if JSON omits them
DEFAULT_SCORES = ["score_9", "score_8_up", "score_7_up", "score_6_up"]

scores   = _normalize_list((_RAW.get("scores") or []) + DEFAULT_SCORES)
core     = _normalize_list(_RAW.get("core"))
extended = _normalize_list(_RAW.get("extended"))
effects  = _normalize_list(_RAW.get("effects"))

def _opts():
    # Combine into one dropdown list with NONE/"" first, then scores → core → extended → effects
    seen, out = set(), [NONE, ""]
    for bucket in [scores, core, extended, effects]:
        for x in bucket:
            if x not in seen:
                out.append(x); seen.add(x)
    return tuple(out) if out else (NONE,)

_OPTS = _opts()

# ---------- node ----------
class SoftSinQuality:
    @classmethod
    def INPUT_TYPES(cls):
        defaults = {
            "quality_1": "score_9" if "score_9" in _OPTS else NONE,
            "quality_2": "score_8_up" if "score_8_up" in _OPTS else NONE,
            "quality_3": NONE,
            "quality_4": NONE,
            "quality_5": NONE,
            "quality_6": NONE,
            "quality_7": NONE,
        }
        return {
            "required": {
                "format": (["weighted_parentheses", "plain", "brackets"], {"default": "weighted_parentheses"}),
                "quality_1": (_OPTS, {"default": defaults["quality_1"]}),
                "quality_2": (_OPTS, {"default": defaults["quality_2"]}),
                "quality_3": (_OPTS, {"default": defaults["quality_3"]}),
                "quality_4": (_OPTS, {"default": defaults["quality_4"]}),
                "quality_5": (_OPTS, {"default": defaults["quality_5"]}),
                "quality_6": (_OPTS, {"default": defaults["quality_6"]}),
                "quality_7": (_OPTS, {"default": defaults["quality_7"]}),
                "block_weight": ("FLOAT", {"default": 1.05, "min": 0.0, "max": 2.0, "step": 0.05}),
            },
            "optional": {
                "extras": ("STRING", {"multiline": True, "default": ""}),
            },
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("quality_text",)
    FUNCTION = "build"
    CATEGORY = "SoftSin/Image Composition"

    def build(self, format,
              quality_1, quality_2, quality_3, quality_4, quality_5, quality_6, quality_7,
              block_weight, extras=""):

        block_weight = _sanitize_weight(block_weight, default=1.05)
        picks = [quality_1, quality_2, quality_3, quality_4, quality_5, quality_6, quality_7]

        tokens, seen = [], set()

        for q in picks:
            tok = _normalize_token(q)
            if _is_set(tok) and tok not in seen:
                tokens.append(_fmt(tok, 1.05, format))
                seen.add(tok)

        for e in _normalize_extras(extras):
            if e not in seen:
                tokens.append(_fmt(e, 1.00, format))
                seen.add(e)

        core = _join_clean(tokens)
        if not core:
            return ("",)

        return (_wrap_block(core, block_weight, format),)

NODE_CLASS_MAPPINGS = {"SoftSinQuality": SoftSinQuality}
NODE_DISPLAY_NAME_MAPPINGS = {"SoftSinQuality": "SoftSin Quality"}
