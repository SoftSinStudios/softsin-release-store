# softsin_male_physical_attributes.py
# SoftSin Physical Male Attributes — single JSON schema
# Reads: softsin_data/physical_male_attributes.json
# Follows SoftSin structure (lighting.py style)

import os, json, re, math

NONE = "(none)"

# ---------- utils ----------
def _is_set(x):
    return x not in (None, "", NONE)

def _fmt(token: str, w: float, style: str) -> str:
    token = (token or "").strip()
    if not _is_set(token):
        return ""
    if style == "plain":
        return token
    if style == "weighted_parentheses":
        return f"({token}:{w:.2f})" if abs(w - 1.0) > 1e-6 else f"({token})"
    if style == "brackets":
        return f"[{token}]"
    return token

def _wrap_block(s: str, w: float, style: str) -> str:
    s = (s or "").strip()
    if not s:
        return s
    if style == "plain" or abs(w - 1.0) < 1e-6:
        return s
    if style == "weighted_parentheses":
        return f"({s}:{w:.2f})"
    if style == "brackets":
        return f"[{s}]"
    return s

def _join_clean(parts):
    parts = [p.strip() for p in parts if p and p.strip() and p.strip() != NONE]
    txt = ", ".join(parts)
    return re.sub(r"(,\s*){2,}", ", ", txt).strip(", ").strip()

def _data_dir():
    here = os.path.dirname(os.path.abspath(__file__))
    for p in [
        os.path.join(here, "softsin_data"),
        os.path.join(os.path.dirname(here), "softsin_data"),
    ]:
        if os.path.isdir(p):
            return p
    p = os.path.join(here, "softsin_data")
    os.makedirs(p, exist_ok=True)
    return p

def _load_json(filename, default):
    path = os.path.join(_data_dir(), filename)
    try:
        with open(path, "r", encoding="utf-8-sig") as f:
            return json.load(f)
    except Exception as e:
        print(f"[SoftSinMalePhysicalAttributes] Warning: failed to load {filename}: {e}")
        return default

def _sanitize_weight(w: float, default=1.0, wmin=0.0, wmax=2.0):
    try:
        w = float(w)
        if not math.isfinite(w):
            return default
    except Exception:
        return default
    return max(wmin, min(wmax, w))

def _opt_from_map(m: dict):
    keys = list(m.keys()) if isinstance(m, dict) else []
    ordered = [NONE] + [k for k in keys if k not in (NONE, "")]
    return tuple(ordered or [NONE])

def _apply_map(m: dict, key: str) -> str:
    if not _is_set(key): return ""
    if not isinstance(m, dict): return key
    if key in (NONE, ""): return ""
    return m.get(key, key)

def _opt_from_list(arr):
    arr = list(arr) if isinstance(arr, list) else []
    out = [NONE] + [x for x in arr if x not in (NONE, "")]
    seen, dedup = set(), []
    for x in out:
        if x not in seen:
            dedup.append(x)
            seen.add(x)
    return tuple(dedup or [NONE])

# ---------- load schema ----------
_DEFAULT = {
    "hair_length_map": {}, "hair_style_map": {}, "figure_map": {},
    "chest_size_map": {}, "chest_shape_map": {}, "face_shape_map": {}, "eye_shape_map": {},
    "eye_colors": [], "facial_hair": [], "skin_tones": [], "skin_surface": [],
    "skin_undertones": [], "skin_details": [], "hair_colors": [], "body_hair": [],
    "presets": []
}
_DOC = _load_json("physical_male_attributes.json", _DEFAULT)

# ---------- derive UI choices ----------
HAIR_LENGTH_KEYS  = _opt_from_map(_DOC.get("hair_length_map", {}))
HAIR_STYLE_KEYS   = _opt_from_map(_DOC.get("hair_style_map", {}))
FIGURE_KEYS       = _opt_from_map(_DOC.get("figure_map", {}))
CHEST_SIZE_KEYS    = _opt_from_map(_DOC.get("chest_size_map", {}))
CHEST_SHAPE_KEYS   = _opt_from_map(_DOC.get("chest_shape_map", {}))
FACE_SHAPE_KEYS   = _opt_from_map(_DOC.get("face_shape_map", {}))
EYE_SHAPE_KEYS    = _opt_from_map(_DOC.get("eye_shape_map", {}))
EYE_COLORS        = _opt_from_list(_DOC.get("eye_colors", []))
FACIAL_HAIR        = _opt_from_list(_DOC.get("facial_hair", []))
SKIN_TONES        = _opt_from_list(_DOC.get("skin_tones", []))
SKIN_SURFACE      = _opt_from_list(_DOC.get("skin_surface", []))
SKIN_UNDERTONES   = _opt_from_list(_DOC.get("skin_undertones", []))
SKIN_DETAILS      = _opt_from_list(_DOC.get("skin_details", []))
HAIR_COLORS       = _opt_from_list(_DOC.get("hair_colors", []))
BODY_HAIR        = _opt_from_list(_DOC.get("body_hair", []))

_PRESETS = _DOC.get("presets", []) if isinstance(_DOC.get("presets", []), list) else []
_PRESET_NAMES = tuple([NONE] + [p.get("name","") for p in _PRESETS if isinstance(p, dict) and p.get("name")])

def _preset_values(name: str):
    if not name or name == NONE: return {}
    for p in _PRESETS:
        if p.get("name") == name:
            return p.get("values", {}) or {}
    return {}

# ---------- node ----------
class SoftSinMalePhysicalAttributes:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "format": (("weighted_parentheses", "plain", "brackets"), {"default": "weighted_parentheses"}),
                "use_preset": ("BOOLEAN", {"default": True}),
                "preset": (_PRESET_NAMES, {"default": _PRESET_NAMES[1] if len(_PRESET_NAMES)>1 else NONE}),
                "figure_macro": (FIGURE_KEYS, {"default": NONE}),
                "chest_size": (CHEST_SIZE_KEYS, {"default": NONE}),
                "chest_size_weight": ("FLOAT", {"default": 1.00, "min": 0.0, "max": 2.0, "step": 0.05}),
                "chest_shape": (CHEST_SHAPE_KEYS, {"default": NONE}),
                "skin_tone": (SKIN_TONES, {"default": NONE}),
                "skin_undertone": (SKIN_UNDERTONES, {"default": NONE}),
                "skin_surface": (SKIN_SURFACE, {"default": NONE}),
                "skin_details": (SKIN_DETAILS, {"default": NONE}),
                "hair_color": (HAIR_COLORS, {"default": NONE}),
                "hair_length": (HAIR_LENGTH_KEYS, {"default": NONE}),
                "hair_style": (HAIR_STYLE_KEYS, {"default": NONE}),
                "face_shape": (FACE_SHAPE_KEYS, {"default": NONE}),
                "eye_shape": (EYE_SHAPE_KEYS, {"default": NONE}),
                "eye_color": (EYE_COLORS, {"default": NONE}),
                "facial_hair": (FACIAL_HAIR, {"default": NONE}),
                "body_hair": (BODY_HAIR, {"default": NONE}),
                "block_weight": ("FLOAT", {"default": 1.00, "min": 0.0, "max": 2.0, "step": 0.05}),
            },
            "optional": {
                "extras": ("STRING", {"multiline": True, "default": ""})
            }
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("attributes_text",)
    FUNCTION = "build"
    CATEGORY = "SoftSin/Physical Attributes"

    def build(self, format, use_preset, preset,
              figure_macro, chest_size, chest_size_weight, chest_shape,
              skin_tone, skin_undertone, skin_surface, skin_details,
              hair_color, hair_length, hair_style,
              face_shape, eye_shape, eye_color, facial_hair,
              body_hair, block_weight, extras=""):

        chest_size_weight = _sanitize_weight(chest_size_weight)
        block_weight = _sanitize_weight(block_weight)

        # ---- apply preset (unchanged from your version) ----
        if use_preset and preset != NONE:
            pv = _preset_values(preset)

            def fill(k, cur): return cur if _is_set(cur) else pv.get(k, cur)

            figure_macro   = fill("figure_macro", figure_macro)
            chest_size     = fill("chest_size", chest_size)
            chest_shape    = fill("chest_shape", chest_shape)
            skin_tone      = fill("skin_tone", skin_tone)
            skin_undertone = fill("skin_undertone", skin_undertone)
            skin_surface   = fill("skin_surface", skin_surface)
            skin_details   = fill("skin_details", skin_details)
            hair_color     = fill("hair_color", hair_color)
            hair_length    = fill("hair_length", hair_length)
            hair_style     = fill("hair_style", hair_style)
            face_shape     = fill("face_shape", face_shape)
            eye_shape      = fill("eye_shape", eye_shape)
            eye_color      = fill("eye_color", eye_color)
            facial_hair    = fill("facial_hair", facial_hair)
            body_hair      = fill("body_hair", body_hair)

            extra_tokens = [pv[k] for k in ("cheekbones", "jawline") if _is_set(pv.get(k))]
            if extras.strip():
                extras = extras + ", " + ", ".join(extra_tokens)
            elif extra_tokens:
                extras = ", ".join(extra_tokens)

        # ---- define masculine fallback BEFORE parts[] is created ----
        auto_masc_face = ""
        if _is_set(hair_length):
            hl = str(hair_length).lower()
            no_beard = (not _is_set(facial_hair) or facial_hair == NONE)
            if ("long" in hl) and no_beard:
                auto_masc_face = "masculine facial structure, strong jawline"

        # ---- build prompt parts ----
        parts = [
            _fmt("male", 1.2, format),
            _fmt(auto_masc_face, 1.15, format),  # safe to reference here

            _fmt(_apply_map(_DOC.get("figure_map", {}), figure_macro), 1.0, format),
            _fmt(_apply_map(_DOC.get("chest_size_map", {}), chest_size), chest_size_weight, format),
            _fmt(_apply_map(_DOC.get("chest_shape_map", {}), chest_shape), 1.0, format),
            _fmt(skin_tone, 1.0, format),
            _fmt(skin_undertone, 1.0, format),
            _fmt(skin_surface, 1.0, format),
            _fmt(skin_details, 1.0, format),
            _fmt(hair_color, 1.0, format),
            _fmt(_apply_map(_DOC.get("hair_length_map", {}), hair_length), 1.0, format),
            _fmt(_apply_map(_DOC.get("hair_style_map", {}), hair_style), 1.0, format),
            _fmt(_apply_map(_DOC.get("face_shape_map", {}), face_shape), 1.0, format),
            _fmt(_apply_map(_DOC.get("eye_shape_map", {}), eye_shape), 1.0, format),
            _fmt(eye_color, 1.0, format),
            _fmt(facial_hair, 1.0, format),
            _fmt(body_hair, 1.0, format)
        ]

        if extras.strip():
            parts.append(extras.strip())

        phrase = _join_clean(parts)
        if not phrase:
            return ("",)

        return (_wrap_block(phrase, block_weight, format),)

# ---- Comfy registration ----
NODE_CLASS_MAPPINGS = {"SoftSinMalePhysicalAttributes": SoftSinMalePhysicalAttributes}
NODE_DISPLAY_NAME_MAPPINGS = {"SoftSinMalePhysicalAttributes": "SoftSin Male Physical Attributes"}
