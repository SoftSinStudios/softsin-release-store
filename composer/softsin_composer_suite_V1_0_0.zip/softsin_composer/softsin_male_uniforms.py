# softsin_male_uniforms.py
# SoftSin Clothing — Male Uniforms (options only; no presets)
# Reads:
#   - softsin_data/male_uniforms.json
# Emits: single STRING (weighted) + optional extras
#
# Cloned from SoftSinFemaleUniforms with category/path adjustments and file rename.

import os, re, json, math

NONE = "(none)"

# ---------- helpers ----------
def _is_set(x):
    return x not in (None, "", NONE)

def _fmt(token: str, w: float, style: str) -> str:
    token = (token or "").strip()
    if not _is_set(token):
        return ""
    if style == "plain":
        return token
    if style == "weighted_parentheses":
        return f"({token}:{w:.2f})" if abs(w - 1.0) > 1e-6 else f"({token})"
    if style == "brackets":
        return f"[{token}]"
    return token

def _wrap_block(s: str, w: float, style: str) -> str:
    s = (s or "").strip()
    if not s:
        return s
    if style == "plain" or abs(w - 1.0) < 1e-6:
        return s
    if style == "weighted_parentheses":
        return f"({s}:{w:.2f})"
    if style == "brackets":
        return f"[{s}]"
    return s

def _sanitize_weight(w: float, default=1.0, wmin=0.0, wmax=2.0):
    try:
        w = float(w)
        if not math.isfinite(w):
            return default
    except Exception:
        return default
    return max(wmin, min(wmax, w))

def _join_clean(parts):
    parts = [p.strip() for p in parts if p and str(p).strip() and str(p).strip() != NONE]
    if not parts:
        return ""
    txt = ", ".join(parts)
    txt = re.sub(r"(,\s*){2,}", ", ", txt).strip(", ").strip()
    out, seen = [], set()
    for seg in [s.strip() for s in txt.split(",")]:
        if seg and seg not in seen:
            out.append(seg)
            seen.add(seg)
    return ", ".join(out)

def _normalize_token(s: str) -> str:
    if not s:
        return ""
    if s == NONE:
        return NONE
    t = s.lower().replace("’", "'").replace("'", "")
    t = t.replace("-", "_")
    t = re.sub(r"\s+", "_", t.strip())
    t = re.sub(r"_+", "_", t)
    return t

def _normalize_extras(extras: str):
    out = []
    for raw in (extras or "").split(","):
        tok = _normalize_token(raw.strip())
        if tok and tok != NONE:
            out.append(tok)
    return out

def _data_dir():
    here = os.path.dirname(os.path.abspath(__file__))
    for p in [
        os.path.join(here, "softsin_data"),
        os.path.join(os.path.dirname(here), "softsin_data"),
    ]:
        if os.path.isdir(p):
            return p
    p = os.path.join(here, "softsin_data")
    os.makedirs(p, exist_ok=True)
    return p

def _load_json(filename, default):
    path = os.path.join(_data_dir(), filename)
    try:
        with open(path, "r", encoding="utf-8-sig") as f:
            return json.load(f)
    except Exception as e:
        print(f"[MaleUniforms] Warning: failed to load {filename}: {e}")
        return default

# ---------- load options (no presets) ----------
# Expected shape in male_uniforms.json:
# {
#   "general_uniforms": [...],
#   "capes_and_hoods": [...],
#   "formal_wear": [...],
#   "tactical_and_pilot": [...],
#   "futuristic": [...],
#   "service_and_religious": [...],
#   "sports_and_training": [...],
#   "costumes": { "general": [...], "animal_costumes": [...] },
#   "traditional_attire": {
#       "chinese_clothes": [...],
#       "japanese_clothes": [...],
#       "korean_clothes": [...],
#       "vietnamese_clothes": [...],
#       "european_clothes": [...]
#   }
# }
_OPTIONS = _load_json("male_uniforms.json", {})

def _opt(path):
    """path like 'formal_wear' or 'traditional_attire.japanese_clothes'."""
    cur = _OPTIONS
    for part in path.split("."):
        if isinstance(cur, dict) and part in cur:
            cur = cur[part]
        else:
            cur = []
            break
    arr = cur if isinstance(cur, list) else []
    if not arr:
        return (NONE,)
    out, seen = [], set()
    base = [NONE, ""]
    for x in base + arr:
        if x not in seen:
            out.append(x)
            seen.add(x)
    return tuple(out)

# emission order
_EMIT_ORDER = [
    "general_uniforms",
    "capes_and_hoods",
    "formal_wear",
    "tactical_and_pilot",
    "futuristic",
    "service_and_religious",
    "sports_and_training",
    "costume_general",
    "costume_animal",
    "trad_chinese",
    "trad_japanese",
    "trad_korean",
    "trad_vietnamese",
    "trad_european"
]

# ---------- node ----------
class SoftSinmaleUniforms:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "format": (["weighted_parentheses", "plain", "brackets"], {"default": "weighted_parentheses"}),
                "general_uniforms": (_opt("general_uniforms"), {"default": NONE}),
                "capes_and_hoods": (_opt("capes_and_hoods"), {"default": NONE}),
                "formal_wear": (_opt("formal_wear"), {"default": NONE}),
                "tactical_and_pilot": (_opt("tactical_and_pilot"), {"default": NONE}),
                "futuristic": (_opt("futuristic"), {"default": NONE}),
                "service_and_religious": (_opt("service_and_religious"), {"default": NONE}),
                "sports_and_training": (_opt("sports_and_training"), {"default": NONE}),
                "costume_general": (_opt("costumes.general"), {"default": NONE}),
                "costume_animal": (_opt("costumes.animal_costumes"), {"default": NONE}),
                "trad_chinese": (_opt("traditional_attire.chinese_clothes"), {"default": NONE}),
                "trad_japanese": (_opt("traditional_attire.japanese_clothes"), {"default": NONE}),
                "trad_korean": (_opt("traditional_attire.korean_clothes"), {"default": NONE}),
                "trad_vietnamese": (_opt("traditional_attire.vietnamese_clothes"), {"default": NONE}),
                "trad_european": (_opt("traditional_attire.european_clothes"), {"default": NONE}),
                "block_weight": ("FLOAT", {"default": 1.00, "min": 0.0, "max": 2.0, "step": 0.05})
            },
            "optional": {
                "extras": ("STRING", {"multiline": True, "default": ""})
            }
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("uniforms_text",)
    FUNCTION = "build"
    CATEGORY = "SoftSin/Male Clothing"

    def build(self, format,
              general_uniforms, capes_and_hoods, formal_wear, tactical_and_pilot,
              futuristic, service_and_religious, sports_and_training,
              costume_general, costume_animal,
              trad_chinese, trad_japanese, trad_korean, trad_vietnamese, trad_european,
              block_weight, extras=""):

        block_weight = _sanitize_weight(block_weight)

        fields = {
            "general_uniforms": general_uniforms,
            "capes_and_hoods": capes_and_hoods,
            "formal_wear": formal_wear,
            "tactical_and_pilot": tactical_and_pilot,
            "futuristic": futuristic,
            "service_and_religious": service_and_religious,
            "sports_and_training": sports_and_training,
            "costume_general": costume_general,
            "costume_animal": costume_animal,
            "trad_chinese": trad_chinese,
            "trad_japanese": trad_japanese,
            "trad_korean": trad_korean,
            "trad_vietnamese": trad_vietnamese,
            "trad_european": trad_european
        }

        tokens = []
        for key in _EMIT_ORDER:
            val = fields.get(key, "")
            if _is_set(val):
                tokens.append(_fmt(_normalize_token(val), 1.05, format))

        for e in _normalize_extras(extras):
            tokens.append(_fmt(e, 1.00, format))

        core = _join_clean(tokens)
        if not core:
            return ("",)

        return (_wrap_block(core, block_weight, format),)

# ---------- registration ----------
NODE_CLASS_MAPPINGS = {"SoftSinmaleUniforms": SoftSinmaleUniforms}
NODE_DISPLAY_NAME_MAPPINGS = {"SoftSinmaleUniforms": "SoftSin male Uniforms"}
