# softsin_loras_triggers.py
# SoftSin LoRaS Triggers — Single Trigger Control
# Reads: softsin_data/loras Female triggers.json
# UI order: format → trigger → block_weight → extras

import os, re, json, math

NONE = "(none)"
JSON_FILE = "female_triggers.json"

# ---------- helpers ----------
def _is_set(x):
    return x not in (None, "", NONE)

def _fmt(token: str, w: float, style: str) -> str:
    token = (token or "").strip()
    if not token or token == NONE:
        return ""
    if style == "plain":
        return token
    if style == "weighted_parentheses":
        return f"({token}:{w:.2f})" if abs(w - 1.0) > 1e-6 else f"({token})"
    if style == "brackets":
        return f"[{token}]"
    return token

def _wrap_block(s: str, w: float, style: str) -> str:
    s = (s or "").strip()
    if not s:
        return s
    if style == "plain" or abs(w - 1.0) < 1e-6:
        return s
    if style == "weighted_parentheses":
        return f"({s}:{w:.2f})"
    if style == "brackets":
        return f"[{s}]"
    return s

def _join_clean(parts):
    parts = [p.strip() for p in parts if p and str(p).strip()]
    txt = ", ".join(parts)
    return re.sub(r"(,\s*){2,}", ", ", txt).strip(", ").strip()

def _sanitize_weight(w: float, default=1.0, wmin=0.0, wmax=2.0):
    try:
        w = float(w)
        if not math.isfinite(w):
            return default
    except Exception:
        return default
    return max(wmin, min(wmax, w))

def _data_dir():
    here = os.path.dirname(os.path.abspath(__file__))
    for p in [
        os.path.join(here, "softsin_data"),
        os.path.join(os.path.dirname(here), "softsin_data"),
    ]:
        if os.path.isdir(p):
            return p
    p = os.path.join(here, "softsin_data")
    os.makedirs(p, exist_ok=True)
    return p

def _load_json_data():
    path = os.path.join(_data_dir(), JSON_FILE)
    if not os.path.exists(path):
        print(f"[softsin_loras_triggers] Missing JSON: {path}")
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data if isinstance(data, dict) else {}
    except Exception as e:
        print(f"[softsin_loras_triggers] Load error: {e}")
        return {}

def _ensure_list(v):
    if isinstance(v, list) and v:
        return v
    return [NONE, ""]

# ---------- node ----------
class SoftSinFemaleTriggers:
    @classmethod
    def INPUT_TYPES(cls):
        data = _load_json_data()
        triggers = _ensure_list(data.get("triggers", []))
        return {
            "required": {
                "format": (["weighted_parentheses", "plain", "brackets"],
                           {"default": "weighted_parentheses"}),
                "trigger": (triggers, {"default": NONE}),
                "block_weight": ("FLOAT",
                                 {"default": 1.00, "min": 0.0, "max": 2.0, "step": 0.05}),
            },
            "optional": {
                "extras": ("STRING", {"multiline": True, "default": ""}),
            },
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("trigger_text",)
    FUNCTION = "build"
    CATEGORY = "SoftSin/Secret Sauce NR"

    def build(self, format, trigger, block_weight, extras=""):
        block_weight = _sanitize_weight(block_weight)
        if not _is_set(trigger):
            return ("",)

        parts = [trigger]
        if extras.strip():
            parts.append(extras.strip())

        phrase = _join_clean(parts)
        if not phrase:
            return ("",)
        return (_wrap_block(phrase, block_weight, format),)

# ---------- registration ----------
NODE_CLASS_MAPPINGS = {"SoftSinFemaleTriggers": SoftSinFemaleTriggers}
NODE_DISPLAY_NAME_MAPPINGS = {"SoftSinFemaleTriggers": "Female Triggers"}
