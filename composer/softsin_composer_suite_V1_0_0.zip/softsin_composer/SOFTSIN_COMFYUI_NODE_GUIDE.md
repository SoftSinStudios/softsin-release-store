# SoftSin Compositor Node Suite — User Guide

SoftSin Studios — Tools for the New Creative Age  
This guide explains how to use the SoftSin node suite inside ComfyUI, how the JSON-driven system works, and how to avoid breaking things.

---

## 1. What this node suite actually is

The SoftSin Compositor nodes are structured prompt builders for ComfyUI.

- They do not generate images on their own.
- They emit well-formed text blocks you plug into your main prompt.
- Behavior is driven by JSON files in `softsin_data/`, not hard-coded Python.

Think of each node as a controlled vocabulary generator:
- You select options from dropdowns.
- The node assembles a weighted phrase.
- That phrase is appended to your prompt as a consistent block.

Example output (environment node):

(misty mountain valley, autumn forest canopy, stone path, cool morning air:1.10)

You wire that into your positive prompt and let the sampler/checkpoint handle the rest.

---

## 2. Installation / where stuff lives

Your directory layout inside ComfyUI:

custom_nodes/
  SoftSin/
    environmental_attributes.py
    <other SoftSin nodes>.py
    softsin_data/
      Environmental_attributes.json
      male_triggers.json
      female_triggers.json
      <other SoftSin JSON files>.json

- `.py` files = Comfy nodes  
- `softsin_data/*.json` = configuration lists

Do not rename or move these unless you know what you are doing.

---

## 3. How the JSON-driven system works

Most SoftSin nodes follow this pattern:

- A JSON file defines keys (identifiers)  
- Node loads that JSON  
- UI shows keys as dropdown options  
- Node outputs a single text block  
- The entire block can be weighted with a slider in ComfyUI

Design rules:

1. Identifiers, not likenesses  
   We use neutral first names (“Ronan”, “Jessica”, “Elias”) — not IP, not last names.

2. Weight is controlled in the node  
   JSONs do not embed token weights.

---

## 4. Environmental Attributes Node

Node: `SoftSin Environmental Attributes`  
Category: `SoftSin/environments`  
Output: one STRING called `environment_text`.

### 4.1 Inputs

- format (weighted_parentheses, plain, brackets)
- region_macro
- terrain
- biome
- canopy
- undergrowth
- water_body
- ground_surface
- landform_feature
- sky_state
- weather_state
- season
- atmospheric_elements
- manmade_presence
- clutter_details
- block_weight (float)
- extras (freeform)

All drop-down values come from:

softsin_data/Environmental_attributes.json

### 4.2 Output

The node:

1. Gathers selected keys  
2. Maps them to phrases via JSON  
3. Joins them into one comma-separated string  
4. Wraps with the chosen output format  
5. Applies block_weight

Example:

(mountain valley, conifer forest, stone path, misty air, overcast sky, early autumn:1.05)

Extras (if present) get appended inside the same block.

---

## 5. Trigger Name Nodes (Male/Female/etc.)

Example JSON:

{
  "schema_version": "1.0",
  "profile": "lora_male_triggers",
  "triggers": [
    "(none)",
    "",
    "Aaron",
    "Elias",
    "Ronan",
    "Marcus"
  ]
}

These nodes:

- Display triggers in a dropdown  
- Convert selection to lower-case tokens  
- Apply global weight via slider  
- Do not embed likenesses or copyrighted identities  

Trigger nodes provide soft bias, not identity enforcement.

---

## 6. Typical Graph Wiring

A standard setup:

[Base Prompt]  ----\
                    +--> [Prompt Combiner] --> [KSampler]
[Environment Node] -/
[Trigger Node] ----/
[Other SoftSin] ---/

SoftSin nodes output STRING blocks.  
You concatenate them before sending to your model.

---

## 7. Safe vs Unsafe JSON Editing

Safe to edit:
- Add new first names  
- Add new environment keys  
- Add new attribute categories  
- Create new SoftSin-style JSON files

Avoid:
- Renaming existing keys  
- Adding full names (no last names)  
- Adding celebrities or characters  
- Editing .py files unless you understand ComfyUI internals

---

## 8. Design Principles

- Structured output, not prompt soup  
- JSON over hard-coding  
- Neutral identifiers  
- Node-level weighting  
- Predictability and clarity

---

## 9. Troubleshooting

**Node missing in ComfyUI**
- Check folder placement  
- Check console for load errors  
- Check JSON names  
- Restart ComfyUI

**Empty dropdowns**
- JSON failed to load  
- JSON formatting error  
- Missing commas/quotes  
- Fix JSON → restart

**Broken after edits**
- Revert JSON from repo  
- Do not rename keys  
- Stick to adding, not rewiring

---

## 10. Official Source / Authenticity

Only official SoftSin releases come from the SoftSin GitHub repository or linked ZIP downloads.

If you obtained this suite from elsewhere:
- Compare file hashes  
- Compare directory structure  
- Check release notes  
- Verify repository origin

SoftSin tools are designed to be structured, ethical, and predictable components within AI workflows.

