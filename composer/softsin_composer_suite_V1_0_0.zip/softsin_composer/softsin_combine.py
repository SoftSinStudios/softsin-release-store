# softsin_combine.py
# SoftSin Combine — join two STRING blocks cleanly and safely.
# Now dedupes, respects inner block formatting, and matches suite standards.

import re

NONE = "(none)"

def _is_set(x):
    return x not in (None, "", NONE)

def _sanitize_str(x):
    return str(x) if not isinstance(x, str) else x

def _join_clean(parts):
    """Normalize commas and spaces, dedupe repeated tokens."""
    txt = ", ".join(parts)
    # Clean only *outside* of parentheses/brackets
    txt = re.sub(r"\s*,\s*", ", ", txt)
    txt = re.sub(r"(,\s*){2,}", ", ", txt)
    txt = re.sub(r"\s{2,}", " ", txt).strip(", ").strip()
    # Deduplicate token-level repeats (simple textual dedupe)
    seen, out = set(), []
    for t in [p.strip() for p in txt.split(",")]:
        if t and t not in seen:
            out.append(t)
            seen.add(t)
    return ", ".join(out)

def _clean_piece(s: str) -> str:
    """Minimal piece cleaner (safe for weighted blocks)."""
    s = _sanitize_str(s)
    s = s.strip()
    if not s:
        return ""
    # avoid stripping valid closing symbols inside tokens
    s = re.sub(r"\s+", " ", s)
    return s

def _join_two(a: str, b: str) -> str:
    parts = [_clean_piece(p) for p in (a, b) if _is_set(p)]
    if not parts:
        return ""
    return _join_clean(parts)

# ---------- node ----------
class SoftSinCombine:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "a": ("STRING", {"multiline": True, "default": ""}),
                "b": ("STRING", {"multiline": True, "default": ""}),
            }
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("combined_text",)
    FUNCTION = "build"
    CATEGORY = "SoftSin/Utilities"

    def build(self, a, b):
        phrase = _join_two(a, b)
        return (phrase if phrase else "",)

# ---------- registration ----------
NODE_CLASS_MAPPINGS = {"SoftSinCombine": SoftSinCombine}
NODE_DISPLAY_NAME_MAPPINGS = {"SoftSinCombine": "SoftSin Combine"}
